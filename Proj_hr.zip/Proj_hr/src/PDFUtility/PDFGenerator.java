package PDFUtility;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;

import org.apache.poi.xwpf.usermodel.UnderlinePatterns;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;

import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.PageSize;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.TabSettings;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import ExcelUtility.ExcelData;
import PDFCreator.PDFcreator;
import WordDocUtility.WordParser;
import WordDocUtility.XWPFWordProvider;
import mail.MailGenerator;



public class PDFGenerator {
	
	private static final String Head_HR="Sabu Thomas";
	private static final String Head_HR_Desig="Chief People Officer";
	private static final String Head_MD="Chetan Garga";
	private static final String Head_MD_Desig="Managing Director";
	private static final String Name="Name";
	private static final String empId="Employee ID";


	private static final String delemeter1 = "<";
	private static final String delemeter2 = ">";	


		private static final ThreadLocal<PDFGenerator> PDFthreadManager = new ThreadLocal<PDFGenerator>()
    {
        protected PDFGenerator initialValue() {
        	return new PDFGenerator();
        	
       }
    };
    public synchronized  static  PDFGenerator getInstance(){
        return PDFthreadManager.get();
      }

	private PDFGenerator(){};
	
	

	
public void PDFGenerate(){
	
	
	
	
try{
	
	Document document = PDFProvider.getInstance().getDocument();
	PDFProvider.getInstance().setPdfWriter();
//	

	PDFProvider.getInstance().SetPDFencrypt(PDFProvider.getInstance().getPDFWriter(), PDFProvider.getInstance().getExceldata().getcolval("Password"), "owner");
	
	PDFProvider.getInstance().getDocument().setPageSize(PageSize.A4);
	PDFProvider.getInstance().getPDFWriter().setPageEvent(PDFHeaderFooter.getInstance());
	PDFProvider.getInstance().getDocument().open();
	
	PDFProvider.getInstance().setParagraph(" ",PDFProvider.getInstance().getfontnormal());
	PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
	PDFProvider.getInstance().getDocument().add(PDFProvider.getInstance().getParagraph());
	
	if(!MailGenerator.getInstance().isIsvariable()){
		PDFProvider.getInstance().setParagraph(" ",PDFProvider.getInstance().getfontnormal());
		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);	
		PDFProvider.getInstance().getDocument().add(PDFProvider.getInstance().getParagraph());
	}
	PDFProvider.getInstance().setParagraph(" ",PDFProvider.getInstance().getfontnormal());
	PDFProvider.getInstance().getParagraph().setSpacingBefore(3);
	PDFProvider.getInstance().getDocument().add(PDFProvider.getInstance().getParagraph());
	
    for(XWPFParagraph XWPFparagraph:XWPFWordProvider.getInstance().getParagraphs()){

    	if(XWPFparagraph.getText().isEmpty()||XWPFparagraph.getText().equals(null)) {
    		PDFProvider.getInstance().setParagraph();

    		document.add(PDFProvider.getInstance().getParagraph());
    	}else if(XWPFparagraph.getText().trim().startsWith("Rs. <Amount>/- (<In Words>) for the year")){


       		
    		String[] splitter=  XWPFparagraph.getText().split(delemeter1);
			String[] splitterindex1 = splitter[1].split(delemeter2);
			System.out.println(splitterindex1[0]);		
			String[] splitterindex2 = splitter[2].split(delemeter2);

		
		
		PDFProvider.getInstance().setParagraph();
//		for(int h=0;h<splitter.length;h++){
			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0],PDFProvider.getInstance().getfontbold()));
			PDFProvider.getInstance().getParagraph().add(new Chunk(PDFProvider.getInstance().getExceldata().getcolval(splitterindex1[0]),PDFProvider.getInstance().getfontbold()));
			PDFProvider.getInstance().getParagraph().add(new Chunk(splitterindex1[1],PDFProvider.getInstance().getfontbold()));
			PDFProvider.getInstance().getParagraph().add(new Chunk(PDFProvider.getInstance().getExceldata().getcolval(splitterindex2[0]),PDFProvider.getInstance().getfontitalic()));
			PDFProvider.getInstance().getParagraph().add(new Chunk(splitterindex2[1],PDFProvider.getInstance().getfontnormal()));
			
       			PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
       			PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());	
    	}else if(XWPFparagraph.getText().trim().startsWith(PDFProvider.getInstance().getMonth())){
    		if(MailGenerator.getInstance().isIsvariable()){
    			PDFProvider.getInstance().setParagraph(PDFProvider.getInstance().getDate(), PDFProvider.getInstance().getfontbold());
    			PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    			PDFProvider.getInstance().getParagraph().setSpacingBefore(15);
    			document.add(PDFProvider.getInstance().getParagraph());
    		}
    	}else if(XWPFparagraph.getText().trim().startsWith("Date")){
    		if(!MailGenerator.getInstance().isIsvariable()){
    			String[] splitter=  XWPFparagraph.getText().split(":");
    			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0],PDFProvider.getInstance().getfontnormal()));
    			PDFProvider.getInstance().getParagraph().add(new Chunk(": ",PDFProvider.getInstance().getfontnormal()));
    			PDFProvider.getInstance().getParagraph().add(new Chunk(PDFProvider.getInstance().getDate(),PDFProvider.getInstance().getfontnormal()));
//    			PDFProvider.getInstance().setParagraph(PDFProvider.getInstance().getDate(), PDFProvider.getInstance().getfontbold());
    			PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    			PDFProvider.getInstance().getParagraph().setSpacingBefore(15);
    			document.add(PDFProvider.getInstance().getParagraph());	
    		}
    	}else if(	XWPFparagraph.getText().trim().startsWith("Effective")){
      		
    		String[] splitter=  XWPFparagraph.getText().split(":");


    		PDFProvider.getInstance().setParagraph();
       		PDFProvider.getInstance().getParagraph().setTabSettings(new TabSettings(25f));
    			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
    			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
    			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
    			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);

       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0].split(":")[0],PDFProvider.getInstance().getfontbold()));
//       			PDFProvider.getInstance().getParagraph().setTabSettings(new TabSettings(40f));
       			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
       			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);

       			PDFProvider.getInstance().getParagraph().add(new Chunk(":"+splitter[1],PDFProvider.getInstance().getfontbold()));
    		

    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		document.add(PDFProvider.getInstance().getParagraph());
    		
    	}else if(XWPFparagraph.getText().trim().startsWith("Employee ID	:")){
      		String[] splitter=  XWPFparagraph.getText().split(delemeter1);

   		String[] splitterindex2 = splitter[1].split(delemeter2);
   		


   		PDFProvider.getInstance().setParagraph();
   		PDFProvider.getInstance().getParagraph().setTabSettings(new TabSettings(25f));
		PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
		PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
		PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
		PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);

   			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0].split(":")[0],PDFProvider.getInstance().getfontbold()));
//   			PDFProvider.getInstance().getParagraph().setTabSettings(new TabSettings(40f));
   			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
   			PDFProvider.getInstance().getParagraph().add(new Chunk(": "+PDFProvider.getInstance().getExceldata().getcolval(splitterindex2[0]),PDFProvider.getInstance().getfontbold()));
    		
//    		PDFProvider.getInstance().setParagraph(XWPFparagraph.getText(), PDFProvider.getInstance().getfontbold());
    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		document.add(PDFProvider.getInstance().getParagraph());
    		
    	}else if(XWPFparagraph.getText().trim().startsWith("Employee ID :")){
      		String[] splitter=  XWPFparagraph.getText().split(delemeter1);

   		String[] splitterindex2 = splitter[1].split(delemeter2);
   		


   		PDFProvider.getInstance().setParagraph();

   			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0],PDFProvider.getInstance().getfontbold()));
   			PDFProvider.getInstance().getParagraph().add(new Chunk(PDFProvider.getInstance().getExceldata().getcolval(splitterindex2[0]),PDFProvider.getInstance().getfontbold()));
    		

    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		document.add(PDFProvider.getInstance().getParagraph());
    		
    	}else if(XWPFparagraph.getText().startsWith("__________")|XWPFparagraph.getText().startsWith(Head_MD)|XWPFparagraph.getText().startsWith(Head_MD_Desig)|XWPFparagraph.getText().startsWith(Head_HR)|XWPFparagraph.getText().startsWith(Head_HR_Desig)){
		
    		PDFProvider.getInstance().setParagraph(XWPFparagraph.getText(), PDFProvider.getInstance().getfontbold());

    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		document.add(PDFProvider.getInstance().getParagraph());
    		
       	}else if(XWPFparagraph.getText().trim().startsWith("Dear")){

      		String[] splitter=  XWPFparagraph.getText().split(delemeter1);

   		String[] splitterindex2 = splitter[1].split(delemeter2);
   		
 

   		PDFProvider.getInstance().setParagraph();

   			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0],PDFProvider.getInstance().getfontnormal()));
   			
   				PDFProvider.getInstance().getParagraph().add(new Chunk(PDFProvider.getInstance().getExceldata().getcolval(splitterindex2[0]),PDFProvider.getInstance().getfontnormal()));
   			
   			PDFProvider.getInstance().getParagraph().add(new Chunk(splitterindex2[1],PDFProvider.getInstance().getfontnormal()));


    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());
    	}else if(XWPFparagraph.getText().trim().startsWith("Name :")){

      		String[] splitter=  XWPFparagraph.getText().split(delemeter1);

   		String[] splitterindex2 = splitter[1].split(delemeter2);
   		
 

   		PDFProvider.getInstance().setParagraph();

   			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0],PDFProvider.getInstance().getfontbold()));
   			
   				PDFProvider.getInstance().getParagraph().add(new Chunk(PDFProvider.getInstance().getExceldata().getcolval(splitterindex2[0]),PDFProvider.getInstance().getfontbold()));
   			
    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());
    		
    	
    	}else if(XWPFparagraph.getText().trim().startsWith("Name		:")){

      		String[] splitter=  XWPFparagraph.getText().split(delemeter1);

   		String[] splitterindex2 = splitter[1].split(delemeter2);
   		
 

   		PDFProvider.getInstance().setParagraph();
   		PDFProvider.getInstance().getParagraph().setTabSettings(new TabSettings(25f));
			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);

   			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0].split(":")[0],PDFProvider.getInstance().getfontbold()));

   			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
   			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
   			PDFProvider.getInstance().getParagraph().add(new Chunk(": "+PDFProvider.getInstance().getExceldata().getcolval(splitterindex2[0]),PDFProvider.getInstance().getfontbold()));

    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());
    		
    	}else if(XWPFparagraph.getText().trim().startsWith("For Allstate")){

    		PDFProvider.getInstance().setParagraph(XWPFparagraph.getText(), PDFProvider.getInstance().getfontbold());
    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(15);
    		document.add(PDFProvider.getInstance().getParagraph());
    		PDFProvider.getInstance().addSignature();
    	}else if(XWPFparagraph.getText().trim().startsWith("Subject:")){

    		PDFProvider.getInstance().setParagraph(XWPFparagraph.getText(), PDFProvider.getInstance().getfontboldunderline());
    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(15);
    		document.add(PDFProvider.getInstance().getParagraph());
//    		PDFProvider.getInstance().addSignature();
    		
    		
    	}else if(XWPFparagraph.getText().trim().startsWith("**Annual Incentive")){

//    		PDFProvider.getInstance().setParagraph(XWPFparagraph.getText(), PDFProvider.getInstance().getfontboldunderline());
//    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
//    		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
//    		document.add(PDFProvider.getInstance().getParagraph());
//       	}else if(XWPFparagraph.getText().trim().startsWith("While")){
       		
    		String[] splitt = XWPFparagraph.getText().split(":");
       		String[] splitter=  splitt[1].split(delemeter1);

       		String[] splitterindex2 = splitter[1].split(delemeter2);
       		String[] splitterindex3 = splitter[2].split(delemeter2);

       		PDFProvider.getInstance().setParagraph();
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitt[0],PDFProvider.getInstance().getfontbold()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(":"+splitter[0],PDFProvider.getInstance().getfontnormal()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(PDFProvider.getInstance().getExceldata().getcolval(splitterindex2[0]),PDFProvider.getInstance().getfontnormal()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitterindex2[1],PDFProvider.getInstance().getfontnormal()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(PDFProvider.getInstance().getExceldata().getcolval(splitterindex3[0]),PDFProvider.getInstance().getfontnormal()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitterindex3[1],PDFProvider.getInstance().getfontnormal()));
//       			PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
       			PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
       			PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());
    	
    	
       	}else if(XWPFparagraph.getText().trim().startsWith("*Flexible Benefit Plan")){
       		
       		String[] splitter=  XWPFparagraph.getText().split("offers");
       		
       		PDFProvider.getInstance().setParagraph();
//       		for(int h=0;h<splitter.length;h++){
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0],PDFProvider.getInstance().getfontbold()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk("offers"+splitter[1],PDFProvider.getInstance().getfontnormal()));
//       		}
       		
       		
//    		PDFProvider.getInstance().setParagraph(XWPFparagraph.getText(), PDFProvider.getInstance().getfontnormal());
    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());
    	
       	}else if(XWPFparagraph.getText().trim().startsWith("Provident Fund")){
       		
       		String[] splitter=  XWPFparagraph.getText().split("mentioned");
       		
       		PDFProvider.getInstance().setParagraph();
//       		for(int h=0;h<splitter.length;h++){
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0],PDFProvider.getInstance().getfontbold()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk("mentioned"+splitter[1],PDFProvider.getInstance().getfontnormal()));
//       		}
       		
       		
//    		PDFProvider.getInstance().setParagraph(XWPFparagraph.getText(), PDFProvider.getInstance().getfontnormal());
    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());
    	
    		
       	}else if(XWPFparagraph.getText().trim().startsWith("The management")){
       		if(XWPFparagraph.getText().contains("Designation")){
       			
       			String[] splitter=  XWPFparagraph.getText().split("1st "+PDFProvider.getInstance().getMonth()+" "+PDFProvider.getInstance().getYear());
//           		String[] splitter=  XWPFparagraph.getText().split(delemeter1);
       			String[] splitterindex1 = splitter[0].split(delemeter1);
//       			
       		String[] splitterindex2 = splitterindex1[1].split(delemeter2);
//       		
       		String[] splitterindex3 = splitterindex1[2].split(delemeter2);
       		
       		
       		PDFProvider.getInstance().setParagraph();
//       		for(int h=0;h<splitter.length;h++){
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitterindex1[0],PDFProvider.getInstance().getfontnormal()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(PDFProvider.getInstance().getExceldata().getcolval(splitterindex2[0]),PDFProvider.getInstance().getfontbold()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitterindex2[1],PDFProvider.getInstance().getfontbold()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(PDFProvider.getInstance().getExceldata().getcolval(splitterindex3[0]),PDFProvider.getInstance().getfontbold()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitterindex3[1],PDFProvider.getInstance().getfontnormal()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk("1st "+PDFProvider.getInstance().getMonth()+" "+PDFProvider.getInstance().getYear(),PDFProvider.getInstance().getfontbold()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[1],PDFProvider.getInstance().getfontnormal()));
       			
//    		document.add(PDFProvider.getInstance().getParagraph());
       			
       		}else{
       		String[] splitter=  XWPFparagraph.getText().split("1st "+PDFProvider.getInstance().getMonth()+" "+PDFProvider.getInstance().getYear());
       		
       		PDFProvider.getInstance().setParagraph();
//       		for(int h=0;h<splitter.length;h++){
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0],PDFProvider.getInstance().getfontnormal()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk("1st "+PDFProvider.getInstance().getMonth()+" "+PDFProvider.getInstance().getYear(),PDFProvider.getInstance().getfontbold()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[1],PDFProvider.getInstance().getfontnormal()));
//       		}
       		
       		}
//    		PDFProvider.getInstance().setParagraph(XWPFparagraph.getText(), PDFProvider.getInstance().getfontnormal());
    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());
    	
    		
    			
    		
    	}else if(XWPFparagraph.getText().startsWith("Strictly")||XWPFparagraph.getText().endsWith("Structure")){
    		PDFProvider.getInstance().setParagraph(XWPFparagraph.getText(), PDFProvider.getInstance().getfontboldunderline());
    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());
//    		
    	}else if(XWPFparagraph.getText().trim().startsWith("Designation")||XWPFparagraph.getText().trim().startsWith("Band")){
//    		
    		
      		String[] splitter=  XWPFparagraph.getText().split(delemeter1);

   		String[] splitterindex2 = splitter[1].split(delemeter2);
   		
//   		System.out.println(splitterindex2[0]);
//   	

   		PDFProvider.getInstance().setParagraph();
//   		for(int h=0;h<splitter.length;h++){
   			PDFProvider.getInstance().getParagraph().setTabSettings(new TabSettings(25f));
   			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
   			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
   			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
   			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
   			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0].split(":")[0],PDFProvider.getInstance().getfontbold()));
//   			PDFProvider.getInstance().getParagraph().setTabSettings(new TabSettings(40f));
   			PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
   			if(XWPFparagraph.getText().trim().startsWith("Band")) PDFProvider.getInstance().getParagraph().add(Chunk.TABBING);
   			PDFProvider.getInstance().getParagraph().add(new Chunk(": "+PDFProvider.getInstance().getExceldata().getcolval(splitterindex2[0]),PDFProvider.getInstance().getfontbold()));
    		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
//    		PDFProvider.getInstance().setAlignment("CENTER");
    	
    		document.add(PDFProvider.getInstance().getParagraph());
    		
//    	}else if(XWPFparagraph.getText().startsWith("aspl@allstate.com")||XWPFparagraph.getText().startsWith("CIN Number")){
//    		XWPFparagraph.getRuns().size();
//    		
//    		for(XWPFRun run:XWPFparagraph.getRuns()){
//    			
//    			System.out.println(XWPFparagraph.getText()+":"+run.getColor());;
//    			
//    		}
    		 
    	}else if(XWPFparagraph.getText().startsWith("Encl")){
    		
      		String[] splitter=  XWPFparagraph.getText().split(":");
       		
       		PDFProvider.getInstance().setParagraph();
//       		for(int h=0;h<splitter.length;h++){
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[0],PDFProvider.getInstance().getfontitalic()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(":",PDFProvider.getInstance().getfontnormal()));
       			PDFProvider.getInstance().getParagraph().add(new Chunk(splitter[1],PDFProvider.getInstance().getfontnormal()));
        		PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
        		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
        		document.add(PDFProvider.getInstance().getParagraph());
        		
        		PDFProvider.getInstance().getDocument().newPage();
        		PDFProvider.getInstance().setParagraph(" ",PDFProvider.getInstance().getfontnormal());
        		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
        		PDFProvider.getInstance().getDocument().add(PDFProvider.getInstance().getParagraph());
        		
        		
//        		PDFProvider.getInstance().setParagraph(" ",PDFProvider.getInstance().getfontnormal());
//        		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
//        		PDFProvider.getInstance().getDocument().add(PDFProvider.getInstance().getParagraph());
//        		HF.onEndPage(PDFProvider.getInstance().getPDFWriter(), PDFProvider.getInstance().getDocument());
        	
    	}else{	
    	PDFProvider.getInstance().setParagraph(XWPFparagraph.getText(), PDFProvider.getInstance().getfontnormal());
    	
    	PDFProvider.getInstance().setAlignment(XWPFparagraph.getAlignment().toString());
//    	PDFProvider.getInstance().setAlignment("");
    	PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
//    	PDFProvider.getInstance().getParagraph().
    	document.add(PDFProvider.getInstance().getParagraph());
    	}
//    	System.out.println(XWPFWordProvider.getInstance().getRuns().size());
    	if(XWPFparagraph.getText().endsWith("below:")){
    		PDFProvider.getInstance().setParagraph();
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());
    		
    		PDFProvider.getInstance().createTable1(); 
    		
    		PDFProvider.getInstance().getDocument().add(PDFProvider.getInstance().getPdftable());
    		continue;
    	}
    	if(XWPFparagraph.getText().endsWith("1st "+PDFProvider.getInstance().getMonth()+" "+PDFProvider.getInstance().getYear())){
    		PDFProvider.getInstance().setParagraph();
    		PDFProvider.getInstance().getParagraph().setSpacingBefore(10);
    		document.add(PDFProvider.getInstance().getParagraph());
    		
    		PDFProvider.getInstance().createTable2(); 
    		PDFProvider.getInstance().getDocument().add(PDFProvider.getInstance().getPdftable());
    		continue;
    	}

    	
    	
    	
//    	int k =0;
    	
    /*	for(XWPFRun run: XWPFWordProvider.getInstance().getRuns()){

//    		System.out.println(XWPFparagraph.getAlignment()+ ", isBold: "+run.isBold()+", isUnderlined: "+run.getUnderline()+", "+"text Position value = "+"isItalic: "+run.isItalic()+", "+"text position value = "+run.getText(run.getTextPosition()));
    		String text = run.getText(run.getTextPosition());
    		System.out.println("k = "+k+" run.getText(run.getTextPosition() = "+text);
//    		new Chunk(content, font)
    		if(run.getText(run.getTextPosition()).equals("null")) continue;
    		String text = run.getText(run.getTextPosition());
    		Font font = PDFProvider.getInstance().getFont(run.isBold(), run.isItalic(), run.getUnderline().toString());
    		PDFGenerator.getInstance().setChunkMap(k, new Chunk(text,font));
//    		PDFProvider.getInstance().getParagraph().add();
    		k++;
    	}
    	PDFProvider.getInstance().setParagraph();
    	for (int p=0; p <  PDFGenerator.getInstance().getChunkMap().size() ;p++){
    		PDFProvider.getInstance().getParagraph().add(PDFGenerator.getInstance().getChunkMap(p));   		
    	}
//    	break; 
*/    	
    	
    }
   
   

	

}catch(Exception e){
	e.getMessage();
	
}finally{
	PDFProvider.getInstance().getDocument().close();
	PDFProvider.getInstance().getPDFWriter().close();
	System.out.println("Letter Created for the Employee :'"+PDFProvider.getInstance().getExceldata().getcolval("Name")+"' and Letter is '"+PDFProvider.getInstance().getExceldata().getcolval("Employee ID")+".PDF'");
}
	
}




	
}
