package PDFUtility;

import java.awt.Color;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Font.FontFamily;
import com.itextpdf.text.FontFactory;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.html.WebColors;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

import ExcelUtility.ExcelData;
import WordDocUtility.XWPFWordProvider;


public class PDFProvider {
	
	private Paragraph paragraph;
	private PdfPTable Pdftable;
	private Document document;
	private PdfWriter PDFWriter;
	private  Image image;
	private File Directory;
	private FileOutputStream OutputStreamFile;
//	public String name;
//	public String FirstName;
	private String Empid;
	private String Amount;
	private String Amount_words;
	private String password;
	private String date;
	private String year;
	private String day;
	private String SignaturePath;
	private String month;
	private int signaturescalefit;
	
	

public int getSignaturescalefit() {
		return signaturescalefit;
	}
	public void setSignaturescalefit(int signaturescalefit) {
		this.signaturescalefit = signaturescalefit;
	}
public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
private String Empname;

private ExcelData exceldata;


public ExcelData getExceldata() {
	return exceldata;
}
public void setExceldata(ExcelData exceldata) {
	this.exceldata = exceldata;
}

	
public String getEmpname() {
	return Empname;
}

public void setEmpName(String name) {
	this.Empname = name;
}

//public String getFirstName() {
//	return FirstName;
//}
//
//public void setFirstName(String firstName) {
//	FirstName = firstName;
//}

public String getEmpid() {
	return Empid;
}

public void setEmpid(String Empid) {
	this.Empid = Empid;
}

public String getPassword() {
	return password;
}

public void setPassword(String password) {
	this.password = password;
}

public String getDate() {
	return date;
}

public void setDate() {
	this.date = PDFProvider.getInstance().getpresentDate();
}

public File getDirectory() {
	return Directory;
}

public String getYear() {
	return year;
}

public void setYear(String year) {
	this.year = year;
}

public String getDay() {
	return day;
}
public void setDay(String day) {
	this.day = day;
}
//public static String getName() {
//	return Name;
//}


	
	

	public String getSignaturePath() {
		return SignaturePath;
	}
	public void setSignaturePath(String partialsignature_path) {
		
		this.SignaturePath = new File(System.getProperty("user.dir"), partialsignature_path).getAbsolutePath();
	}
	private void setArialFontFactory(){
		FontFactory.register("c:\\windows\\fonts\\arial.ttf");
//		FontFactory.r
	}
	public Paragraph getParagraph() {
		return paragraph;
	}

	public void setParagraph() {
		this.paragraph = new Paragraph();
	}
	public void setParagraph(String paragraphText, Font font) {
		this.paragraph = new Paragraph(paragraphText, font);
	}
	public PdfPTable getPdftable() {
		return Pdftable;
	}

	public void setPdftable(int TableIndex) {
		this.Pdftable = new PdfPTable(XWPFWordProvider.getInstance().getTotalcolumns(XWPFWordProvider.getInstance().getTable(TableIndex).getRows().get(0)));
	}
	
	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}
	
	public Document getDocument() {
		return document;
	}

	public void setDocument(Document document) {
		this.document =document;
	}
	public PdfWriter getPDFWriter() {
		return PDFWriter;
	}
	public void setPdfWriter() throws DocumentException, FileNotFoundException {
		this.PDFWriter =PdfWriter.getInstance(PDFProvider.getInstance().getDocument(), PDFProvider.getInstance().getOutputStreamFile());
	}


	
	public  Font getfontbold(){
		PDFProvider.getInstance().setArialFontFactory();		
		return FontFactory.getFont("Arial", 12, Font.BOLD);
//		return (new Font(FontFamily.TIMES_ROMAN, 12,  Font.BOLD));
	}
		
	public  Font getfontitalic(){
		PDFProvider.getInstance().setArialFontFactory();
		return FontFactory.getFont("Arial", 12,  Font.ITALIC);
	}
	
	
	public  Font getfontboldunderline(){
		PDFProvider.getInstance().setArialFontFactory();
		return FontFactory.getFont("Arial", 12,  Font.BOLD | Font.UNDERLINE);
	}
	
	public  Font getfontboldunderlinewithAllstateblue(){
		PDFProvider.getInstance().setArialFontFactory();
		BaseColor myColor = WebColors.getRGBColor("#0076B8");
		return FontFactory.getFont("Arial", 12, Font.UNDERLINE,myColor);
	}
	
	public  Font getfontboldItalicunderline(){
		PDFProvider.getInstance().setArialFontFactory();
		return FontFactory.getFont("Arial", 12,  Font.BOLD | Font.UNDERLINE | Font.ITALIC);
	}
	
	public  Font getfontboldItalic(){
		PDFProvider.getInstance().setArialFontFactory();
		return FontFactory.getFont("Arial", 12,Font.BOLD | Font.ITALIC);
	}
	
	public  Font getfontnormal(){
		return FontFactory.getFont("Arial", 12);
	}
	
	public  Font getfontnormalwitBlueColor(){
//		Font f = FontFactory.getFont("Arial", 9);
//		f.setColor(BaseColor.);
//		Text text = new Text("");
		BaseColor myColor = WebColors.getRGBColor("2F5496");
		return FontFactory.getFont("Arial", 10, myColor);
	}
	
	public void setAlignment(String placealignment){
		
		if(placealignment.equalsIgnoreCase("CENTER"))
//			case "CENTER":
			PDFProvider.getInstance().getParagraph().setAlignment(Element.ALIGN_CENTER);
//			break;
//		case "RIGHT":
		else if(placealignment.equalsIgnoreCase("RIGHT"))
			PDFProvider.getInstance().getParagraph().setAlignment(Element.ALIGN_RIGHT);
//			break;
//		default:
	
		else{
			PDFProvider.getInstance().getParagraph().setAlignment(Element.ALIGN_LEFT);
		
			PDFProvider.getInstance().getParagraph().setAlignment(Element.ALIGN_JUSTIFIED);		
		}
		
		
	}
	
	public Font getFont(boolean bold,boolean italic, String Underline){
		
		if(bold==true&&italic==true&& Underline.equalsIgnoreCase("SINGLE")){			
			return PDFProvider.getInstance().getfontboldItalicunderline();
		}else if((bold==true&&italic==false&& Underline.equalsIgnoreCase("NONE"))){
			return PDFProvider.getInstance().getfontbold();
		}else if((bold==false&&italic==true&& Underline.equalsIgnoreCase("NONE"))){
			return PDFProvider.getInstance().getfontitalic();
		}else if((bold==true&&italic==true&& Underline.equalsIgnoreCase("NONE"))){
			return PDFProvider.getInstance().getfontboldItalic();
		}else if((bold==false&&italic==false&& Underline.equalsIgnoreCase("SINGLE"))){
			return PDFProvider.getInstance().getfontboldunderline();
		}else{
			return PDFProvider.getInstance().getfontnormal();
		}		
		
	}

//	public FileOutputStream getOutputStreamFile() {
//		return OutputStreamFile;
//	}
	public void addSignature(){
		Image image;
		try {
			image = Image.getInstance(PDFProvider.getInstance().getSignaturePath());
			image.setAlignment(Image.ALIGN_LEFT);
			image.scaleToFit(getSignaturescalefit(), getSignaturescalefit());
			PDFProvider.getInstance().getDocument().add(image);
		} catch (IOException | DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	public FileOutputStream getOutputStreamFile() throws FileNotFoundException {
		return OutputStreamFile = new FileOutputStream(new File(PDFProvider.getInstance().getDirectory().getAbsolutePath()+"\\"+PDFProvider.getInstance().getEmpid()+".pdf"));
	}


//	public String getName() {
//		return name;
//	}
//
//	public void setName(String name) {
//		this.name = name;
//	}



	public void setDirectory(String PDFDirectory) {
//		Directory = directory;
		this.Directory = new File( System.getProperty("user.dir"), PDFDirectory );
		if(!this.Directory.exists()){
			this.Directory.mkdirs();
		}	
		this.Directory= new File(this.Directory.getAbsolutePath());
	}
	private static final ThreadLocal<PDFProvider> PDFManager = new ThreadLocal<PDFProvider>()
			{
				protected PDFProvider initialValue(){
					return new PDFProvider();
				}
			};
			
	public synchronized static PDFProvider getInstance(){
		return PDFManager.get();
	}
	
	private PDFProvider()
	{
		
	}
	
	
	public String  (){
	    Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	    String strDate = sdf.format(cal.getTime());
//	    strDate  = "30/04/2018";
	    String strdat[] = strDate.split("/");
	    
	    String day = strdat[0].substring(0,1).contains("0")?strdat[0].substring(1, 2):strdat[0];
	    String year = strdat[2];

	    String [] monthNames = new String[]{"January", "February", "March", "April", "May", "June",
		                  "July", "August", "September", "October", "November", "December"};

	    Date d = new Date();
	    PDFProvider.getInstance().setYear(year);
	
	    PDFProvider.getInstance().setMonth(monthNames[d.getMonth()]);
		return (monthNames[d.getMonth()]+" "+day+","+year);
		
	}
	 public void insertCell(PdfPTable table, String text, int align, int tableallign, int colspan,String Bckgroundcolor, Font font) throws DocumentException{
		   
		  //create a new cell with the specified Text and Font
		  PdfPCell cell = new PdfPCell(new Phrase(text.trim(), font));
		  //set the cell alignment
		  cell.setHorizontalAlignment(align);
		  if (!(Bckgroundcolor.equals("auto"))){
		  BaseColor myColor = WebColors.getRGBColor(Bckgroundcolor);
//		  System.out.println(Bckgroundcolor);
		  cell.setBackgroundColor(myColor);
		  }
		  //set the cell column span in case you want to merge two or more cells
		  cell.setColspan(colspan);
		  //in case there is no text and you wan to create an empty row
		  if(text.trim().equalsIgnoreCase("")){
		   cell.setMinimumHeight(10f);
		  }
		  table.setWidths(new int[]{95,45});
		  table.setHorizontalAlignment(tableallign);
		  table.setWidthPercentage(65);
		  //add the call to the table
		  table.addCell(cell);
		  
		   
		 }
	 
	 public void createTable1() throws DocumentException{
		 PDFProvider.getInstance().setPdftable(0);
		 int rowindex =0;
		    for (XWPFTableRow row:XWPFWordProvider.getInstance().getTable(0).getRows()){
		    	
		    	int cellindex= 0;
		    	for(XWPFTableCell cell: row.getTableCells()){
//		    		System.out.println();
//		    		System.out.println("Cell Color "+cell.);
//		    		System.out.println(cell.getText() + "cellindex = "+cellindex);
		    		
		    		if (rowindex==0&&cellindex ==1){
		    			PDFProvider.getInstance().insertCell(PDFProvider.getInstance().getPdftable(), cell.getText(), Element.ALIGN_CENTER,70, 1,cell.getColor(), PDFProvider.getInstance().getfontbold());
		    		}else if(rowindex==0&&cellindex ==0){
		    			PDFProvider.getInstance().insertCell(PDFProvider.getInstance().getPdftable(), cell.getText(), Element.ALIGN_LEFT, 70,1,cell.getColor(),PDFProvider.getInstance().getfontbold());
		    		}else if(rowindex>0 &&cellindex ==0)  {		
		    				PDFProvider.getInstance().insertCell(PDFProvider.getInstance().getPdftable(), cell.getText(), Element.ALIGN_LEFT, 70,1, cell.getColor(),PDFProvider.getInstance().getfontnormal());
		    		}else if(rowindex>0 &&cellindex ==1){
		    				PDFProvider.getInstance().insertCell(PDFProvider.getInstance().getPdftable(), PDFProvider.getInstance().getExceldata().getcolval(cell.getText())+"/-", Element.ALIGN_RIGHT, 70,1,cell.getColor(), PDFProvider.getInstance().getfontbold());
		    				
		    		}	
		    			cellindex++;
		    	}
		    	rowindex++;
		    
		    }
	 }
	 
	 public void createTable2() throws DocumentException{
		 PDFProvider.getInstance().setPdftable(1);
		 int rowindex =0;
		 int totalrows = XWPFWordProvider.getInstance().getTable(1).getRows().size();
		
	    for (XWPFTableRow row:XWPFWordProvider.getInstance().getTable(1).getRows()){
	    	if ((row.getTableCells().get(0).getText().trim().equals("Statutory Bonus")) && (Integer.valueOf(PDFProvider.getInstance().getExceldata().getcolval("Statutory Bonus"))==0)) {rowindex++;continue;}
	    	int cellindex= 0;
	    	for(XWPFTableCell cell: row.getTableCells()){
	    		
	    		if (rowindex==0){
//	    			System.out.println("Cell Color "+cell.getColor());
	    			PDFProvider.getInstance().insertCell(PDFProvider.getInstance().getPdftable(), cell.getText(), Element.ALIGN_CENTER, Element.ALIGN_CENTER,1,cell.getColor(), PDFProvider.getInstance().getfontbold());
//	    		PDFProvider.getInstance().insertCell(PDFProvider.getInstance().getPdftable(), cell.getText(), Element.ALIGN_CENTER, 1, PDFProvider.getInstance().getfontbold());
	    		
	    		}else if((rowindex>0 &&rowindex<(totalrows-3)) &&cellindex ==0) { 		
    				PDFProvider.getInstance().insertCell(PDFProvider.getInstance().getPdftable(), cell.getText(), Element.ALIGN_LEFT,Element.ALIGN_CENTER, 1,cell.getColor(), PDFProvider.getInstance().getfontnormal());
	    		}else if((rowindex>0 && rowindex<(totalrows-3)) &&cellindex ==1){
	    			
    				PDFProvider.getInstance().insertCell(PDFProvider.getInstance().getPdftable(),  PDFProvider.getInstance().getExceldata().getcolval(cell.getText()), Element.ALIGN_RIGHT,Element.ALIGN_CENTER, 1,cell.getColor(), PDFProvider.getInstance().getfontnormal());
	    		}else if((totalrows-rowindex)<=3 &&cellindex ==0) { 		
    				PDFProvider.getInstance().insertCell(PDFProvider.getInstance().getPdftable(), cell.getText(), Element.ALIGN_LEFT,Element.ALIGN_CENTER, 1,cell.getColor(), PDFProvider.getInstance().getfontbold());
	    		}else if((totalrows-rowindex)<=3 &&cellindex ==1) { 		
    				PDFProvider.getInstance().insertCell(PDFProvider.getInstance().getPdftable(),  PDFProvider.getInstance().getExceldata().getcolval(cell.getText()), Element.ALIGN_RIGHT,Element.ALIGN_CENTER, 1,cell.getColor(), PDFProvider.getInstance().getfontbold());
	    		}
    			cellindex++;
	    	}
	    	rowindex++;
	    }
	 }
	 
	
  public void SetPDFencrypt(PdfWriter writer, String PWD, String owner){
		try {
			writer.setEncryption(PWD.getBytes(), owner.getBytes(), writer.ALLOW_PRINTING, writer.ENCRYPTION_AES_128);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}




	
}

