package PDFUtility;







import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;

import com.itextpdf.text.BadElementException;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.ExceptionConverter;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.Rectangle;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfName;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfTemplate;
import com.itextpdf.text.pdf.PdfWriter;

import PDFCreator.PDFcreator;

public class PDFHeaderFooter extends PdfPageEventHelper {

	private static final String Allstate_LOGO= "Files\\allstatelogo.png";
	private static final String Allstate_Haeder="Allstate Solutions Private Limited";
	private static final String Allstate_Num="CIN Number U74900KA2012FTC064201";
	 
//	private static final String Allstate_Addressline1="RMZ Ecoworld, 7th Floor, Building No. 1, Devarabeesanahalli, Varthur Hobli,";	
//	private static final String Allstate_Addressline2="Bangalore � 560 037, India. Tel: +91-80-3089 0000, www.allstate.com/India";
	private static final String Allstate_Addressline1="RMZ Ecoworld, 7th Floor, Building No. 1, Devarabeesanahalli, Varthur Hobli,";	
	private static final String Allstate_Addressline2="Bangalore- 560103, India. Tel: +91-80-30890000, Fax: +91-80-30890506";
	private static final String Allstate_Addressline3="www.allstate.com/india/ aspl@allstate.com";	
	private static final String Allstate_Addressline31="www.allstate.com/india/ ";	
	private static final String Allstate_Addressline32="aspl@allstate.com";	
	private static final String Allstate_Addressline4="(Formerly, Northbrook Services India Pvt Ltd. 67-4, 4th Cross, Lavelle Road Bangalore- 560001)";
	


	private static final ThreadLocal<PDFHeaderFooter> PDFthreadManager = new ThreadLocal<PDFHeaderFooter>()
    {
        protected PDFHeaderFooter initialValue() {
        	return new PDFHeaderFooter();
        	
       }
    };
    public synchronized  static  PDFHeaderFooter getInstance(){
        return PDFthreadManager.get();
      }

	private PDFHeaderFooter(){};

    @Override
    public void onEndPage(PdfWriter writer, Document document) {
        try {
			addHeader(writer,document);
			addFooter(writer, document);
		} catch (MalformedURLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

    }

    private void addHeader(PdfWriter writer,Document document) throws MalformedURLException, IOException, DocumentException{
//    	PdfPTable header = new PdfPTable(1);
    	
    	
    	ColumnText.showTextAligned(writer.getDirectContent(), Element.ALIGN_RIGHT, new Phrase(Allstate_Num,PDFProvider.getInstance().getfontnormalwitBlueColor()), (document.left() - document.right()) / 2 + 850, document.top()+15, 0);
//    	 PdfPTable foot = new PdfPTable(1);
//         PdfPCell footCell = new PdfPCell(new Phrase(Allstate_Num, PDFProvider.getInstance().getfontbold()));
//         footCell.setColspan(1);
////         footCell.setPaddingLeft(15);
////         System.out.println((document.left() - document.right()) / 2+100);
////         footCell.setPaddingRight(15);
//         footCell.setHorizontalAlignment(Element.ALIGN_RIGHT);
//         footCell.setBorder(Rectangle.NO_BORDER);
//         foot.addCell(footCell);
         
         
    	PDFProvider.getInstance().setImage(Image.getInstance(new File(System.getProperty("user.dir"), Allstate_LOGO).getAbsolutePath()));
    	Image image = PDFProvider.getInstance().getImage();
    	
//        image.setAlignment(Image.MIDDLE);
    
        image.scaleToFit(320, 270);
        
//        Image img = Image.getInstance("url/logo.png");
//        img.scaleToFit(100,100);  
        image.setAbsolutePosition((document.left() - document.right()) / 2 + 400, document.top()-35);
        image.setAlignment(Element.ALIGN_CENTER);          
        writer.getDirectContent().addImage(image);
        
//        foot.writeSelectedRows(0, -1, 34, 803, writer.getDirectContent());
/*//        header.setColspan(1);
//        header.setPaddingLeft(15);
//        header.setBorder(Rectangle.NO_BORDER);
        header.addCell(image);
        PdfPCell cellimage = new PdfPCell();
        cellimage.setColspan(1);
        cellimage.setPadding(15);
        cellimage.setBorder(Rectangle.NO_BORDER);
        header.addCell(cellimage);*/
//        document.add(image);
    	
//        header.writeSelectedRows(0, -1, 34, 803, writer.getDirectContent());
    }
    	
    	
    	/*
        PdfPTable header = new PdfPTable(2);
        try {
            // set defaults
            header.setWidths(new int[]{24,1});
            header.setTotalWidth(2500);
            header.setLockedWidth(true);;;
//            header.se
            header.getDefaultCell().setFixedHeight(30);
            header.getDefaultCell().setBorder(Rectangle.NO_BORDER);
//            header.getDefaultCell().setBorderColor(BaseColor.LIGHT_GRAY);

            // add image
//            Phrase phrase = new Phrase(string, font)
//            Image logo = Image.getInstance(PDFHeaderFooter.class.getResource("/allstatelogo.g"));
            Image logo = Image.getInstance( new File(System.getProperty("user.dir"), "Files\\allstatelogo.png").getAbsolutePath());
           
            logo.setAlignment(logo.ALIGN_MIDDLE);
            
            logo.scaleToFit(350, 500);
            header.addCell(logo);

            // add text
            PdfPCell text = new PdfPCell();
            text.setPaddingBottom(15);
//            text.setPaddingLeft(10);
//            text.setBorder(Rectangle.BOTT);
////            text.setBorderColor(BaseColor.LIGHT_GRAY);
////            text.addElement(new Phrase("iText PDF Header Footer Example", new Font(Font.FontFamily.HELVETICA, 12)));
////            text.addElement(new Phrase("http://memorynotfound.com", new Font(Font.FontFamily.HELVETICA, 8)));
            header.addCell(text);


    }}

*/    
    
    private void addFooter(PdfWriter writer, Document document) throws DocumentException{
    	
    	
    	
    	 PdfPTable foot = new PdfPTable(1);
         PdfPCell footCell = new PdfPCell(new Phrase(Allstate_Haeder, PDFProvider.getInstance().getfontbold()));
         footCell.setColspan(1);
//         footCell.setPaddingLeft(15);
//         System.out.println((document.left() - document.right()) / 2+100);
//         footCell.setPaddingRight(15);
         footCell.setHorizontalAlignment(Element.ALIGN_CENTER);
         footCell.setBorder(Rectangle.NO_BORDER);
         foot.addCell(footCell);
         
         footCell = new PdfPCell(new Phrase(Allstate_Addressline1, PDFProvider.getInstance().getfontnormal()));
         footCell.setColspan(1);
         footCell.setHorizontalAlignment(Element.ALIGN_CENTER);
//         footCell.setPaddingLeft(15);
         footCell.setBorder(Rectangle.NO_BORDER);
         foot.addCell(footCell);
         
         footCell = new PdfPCell(new Phrase(Allstate_Addressline2, PDFProvider.getInstance().getfontnormal()));
         footCell.setColspan(1);
//         footCell.setPaddingLeft(15);
//         footCell.setPaddingRight(Element.ALIGN_CENTER);
         footCell.setHorizontalAlignment(Element.ALIGN_CENTER);
         footCell.setBorder(Rectangle.NO_BORDER);
         
         foot.addCell(footCell);

    		PDFProvider.getInstance().setParagraph();
//    		for(int h=0;h<splitter.length;h++){
//    			PDFProvider.getInstance().getParagraph().add(new Chunk(Allstate_Addressline31, PDFProvider.getInstance().getfontboldunderlinewithAllstateblue()));
//    			PDFProvider.getInstance().getParagraph().add(new Chunk(Allstate_Addressline32, PDFProvider.getInstance().getfontboldunderlinewithAllstateblue()));
    			
         
//         footCell = new PdfPCell(new Phrase(Allstate_Addressline31, PDFProvider.getInstance().getfontboldunderlinewithAllstateblue()));
//         footCell = new PdfPCell(new Phrase(Allstate_Addressline32, PDFProvider.getInstance().getfontboldunderlinewithAllstateblue()));
         
//         footCell = new PdfPCell();
         footCell = new PdfPCell(new Phrase(Allstate_Addressline3, PDFProvider.getInstance().getfontboldunderlinewithAllstateblue()));
//         footCell.addElement(PDFProvider.getInstance().getParagraph());
         footCell.setColspan(1);
         
//         footCell.setPaddingLeft(15);
//         footCell.setPaddingRight(Element.ALIGN_CENTER);
         footCell.setHorizontalAlignment(Element.ALIGN_CENTER);
         footCell.setBorder(Rectangle.NO_BORDER);
         
         foot.addCell(footCell);
         footCell = new PdfPCell(new Phrase(Allstate_Addressline4, PDFProvider.getInstance().getfontnormal()));
         footCell.setColspan(1);
//         footCell.setPaddingLeft(15);
//         footCell.setPaddingRight(Element.ALIGN_CENTER);
         footCell.setHorizontalAlignment(Element.ALIGN_CENTER);
         footCell.setBorder(Rectangle.NO_BORDER);
         
         foot.addCell(footCell);
//         foot.addCell(footCell);
         foot.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//Rectangle page = document.getPageSize();

         foot.setTotalWidth(523);
//         foot.writeSelectedRows(0, -1, 35, 64, writer.getDirectContent());
         foot.writeSelectedRows(0, -1, 35, 85, writer.getDirectContent());
    	/*
		PDFProvider.getInstance().setParagraph(Allstate_Haeder, PDFProvider.getInstance().getfontbold());
		
		PDFProvider.getInstance().setAlignment("CENTER");
		PDFProvider.getInstance().getParagraph().setAlignment(10);
		document.add(PDFProvider.getInstance().getParagraph());
		PDFProvider.getInstance().setParagraph(Allstate_Addressline1, PDFProvider.getInstance().getfontnormal());
		
		PDFProvider.getInstance().setAlignment("CENTER");
		PDFProvider.getInstance().getParagraph().setAlignment(10);
		document.add(PDFProvider.getInstance().getParagraph());
		PDFProvider.getInstance().setParagraph(Allstate_Addressline2, PDFProvider.getInstance().getfontnormal());
		
		PDFProvider.getInstance().setAlignment("CENTER");
		PDFProvider.getInstance().getParagraph().setAlignment(10);
		document.add(PDFProvider.getInstance().getParagraph());
    	
*/
/*PdfContentByte cb = writer.getDirectContent();
		
//        	 Phrase header = new Phrase("this is a header", ffont);
		
		 Phrase footer = new Phrase(Allstate_Haeder+"\n"+Allstate_Addressline1+"\n"+Allstate_Addressline2, new Font(Font.FontFamily.HELVETICA, 10));
//		Phrase f2 =  new Phrase(Allstate_Addressline2, new Font(Font.FontFamily.HELVETICA, 10));
//		Phrase f3 =  new Phrase(Allstate_Addressline2, new Font(Font.FontFamily.HELVETICA, 10));
//             ColumnText.showTextAligned(cb, Element.ALIGN_CENTER,
//                     header,
//                     (document.right() - document.left()) / 2 + document.leftMargin(),
//                     document.top() + 10, 0);
		
		 ColumnText.showTextAligned(cb, Element.ALIGN_CENTER,
		         footer,
		         (document.right() - document.left()) / 2 + document.leftMargin(),
		         document.bottom() - 20, 0);
//		 ColumnText.showTextAligned(cb, Element.ALIGN_CENTER,
//		         f2,
//		         (document.right() - document.left()) / 2 + document.leftMargin(),
//		         document.bottom() - 10, 0);
//		 ColumnText.showTextAligned(cb, Element.ALIGN_CENTER,
//		         f3,
//		         (document.right() - document.left()) / 2 + document.leftMargin(),
//		         document.bottom() - 10, 0);
//		// set defaults
//            footer.setWidths(new int[]{24, 2, 1});
//            footer.setTotalWidth(527);
//            footer.setLockedWidth(true);
//            footer.getDefaultCell().setFixedHeight(40);
////            footer.getDefaultCell().setBorder(Rectangle.TOP);
////            footer.getDefaultCell().setBorderColor(BaseColor.LIGHT_GRAY);
//
//            // add copyright
//            footer.addCell(new Phrase(Allstate_Haeder, new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD)));
//            footer.addCell(new Phrase(Allstate_Addressline1, new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD)));
//            footer.addCell(new Phrase(Allstate_Addressline2, new Font(Font.FontFamily.HELVETICA, 10, Font.BOLD)));
//            // add current page count
//            footer.getDefaultCell().setHorizontalAlignment(Element.ALIGN_CENTER);
//            footer.addCell(new Phrase(String.format("Page %d of", writer.getPageNumber()), new Font(Font.FontFamily.HELVETICA, 8)));
*/    }

    public void onCloseDocument(PdfWriter writer, Document document) {
    	

//    	PDFProvider.getInstance().getPDFWriter().close();
  /*      int totalLength = String.valueOf(writer.getPageNumber()).length();
        int totalWidth = totalLength * 5;
        ColumnText.showTextAligned(t, Element.ALIGN_RIGHT,
                new Phrase(String.valueOf(writer.getPageNumber()), new Font(Font.FontFamily.HELVETICA, 8)),
                totalWidth, 6, 0);*/
    }
}