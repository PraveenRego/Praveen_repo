package PDFCreator;

import org.apache.poi.hpsf.DocumentSummaryInformation;
import org.apache.poi.hwpf.HWPFDocument;
import org.apache.poi.hwpf.extractor.WordExtractor;
import org.apache.poi.hwpf.usermodel.HeaderStories;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.model.XWPFHeaderFooterPolicy;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFFooter;
import org.apache.poi.xwpf.usermodel.XWPFHeader;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.xmlbeans.XmlException;

import com.itextpdf.text.BaseColor;
import com.itextpdf.text.Chunk;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Image;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.log.SysoCounter;
import com.itextpdf.text.pdf.CMYKColor;
import com.itextpdf.text.pdf.PdfDocument;
import	com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;
//import com.jayway.jsonpath.InvalidPathException;

import org.apache.poi.poifs.filesystem.*;
import org.apache.poi.hpsf.DocumentSummaryInformation;
import org.apache.poi.*;
//import org.apache.poi.hwpf.extractor.*;
//import org.apache.poi.hwpf.usermodel.HeaderStories;
import org.apache.poi.hdf.extractor.HeaderFooter;

import java.awt.Color;
import java.io.*;
import java.net.MalformedURLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;


public class PDFcreator {
	
	private  Image image;
	private Document doc;
	private  Paragraph pg;
	public String name;
	public String FirstName;
	public String empid;
	public String Amount;
	public String Amount_words;
	private String password;
	private String date;
	
	private static final String Allstate_logo="For Allstate";
	private static final String Allstate_Haeder="Allstate Solutions Private Limited";
	private static final String Allstate_Addressline1="RMZ Ecoworld, 7th Floor, Building No. 1, Devarabeesanahalli, Varthur Hobli,";
	
	private static final String Allstate_Addressline2="Bangalore � 560 037, India. Tel: +91-80-3089 0000, www.allstate.com/India";
	private static final String Name="Name";
	private static final String empId="Employee ID:";

	private static final String Allstate_Delimiter="For Allstate";

	private static final String Month="February";
	private static final String Subject="Subject";
	
	private static final String AllstateDelimiter2="Dear";
	
	private static final String Italic_Info="Confidential Information";
	
	private static final String Head_HR="Sabu Thomas";
	private static final String Head_HR_Desig="Chief People Officer";
private List<XWPFParagraph> docFileParagraphs = new ArrayList<XWPFParagraph>();


	public String getDate() {
		return date;
	}

	public List<XWPFParagraph> getDocFileParagraphs() {
		return docFileParagraphs;
	}

	public void setDocFileParagraphs(String FileName) {
		FileInputStream fis;
		try {
			fis = new FileInputStream(FileName);
			XWPFDocument xdoc = new XWPFDocument(OPCPackage.open(fis));
		       List<XWPFParagraph> paraList = xdoc.getParagraphs();
		       this.docFileParagraphs = paraList;


		}
		
		catch(Exception c){
			System.out.println(c);
		}
	}

	
	private String year;
			
	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public void setDate() {
		this.date = PDFcreator.getInstance().getpresentDate();
	}


	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public Image getImage() {
		return image;
	}

	public void setImage(Image image) {
		this.image = image;
	}

	public Document getDoc() {
		return doc;
	}

	public void setDoc(Document doc) {
		this.doc = doc;
	}

	public Paragraph getPg() {
		return pg;
	}

	public void setPg(Paragraph pg) {
		this.pg = pg;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getFirstName() {
		return FirstName;
	}

	public void setFirstName(String firstName) {
		FirstName = firstName;
	}

	public String getEmpid() {
		return empid;
	}

	public void setEmpid(String empid) {
		this.empid = empid;
	}

	public String getAmount() {
		return Amount;
	}

	public void setAmount(String amount) {
		Amount = amount;
	}

	public String getAmount_words() {
		return Amount_words;
	}

	public void setAmount_words(String amount_words) {
		Amount_words = amount_words;
	}


	  private static final ThreadLocal<PDFcreator> PDFManager = new ThreadLocal<PDFcreator>()
	    {
	        protected PDFcreator initialValue() {
	        	return new PDFcreator();
	        	
	       }
	    };
	    public synchronized  static  PDFcreator getInstance(){
	        return PDFManager.get();
	      }

	    private PDFcreator()
	    {
	    	
	    }
	    
	    

	
	private String getpresentDate(){
	    Calendar cal = Calendar.getInstance();
	    SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
	    String strDate = sdf.format(cal.getTime());
	    String strdat[] = strDate.split("/");
	    
	    String day = strdat[0].contains("0")?strdat[0].substring(1, 2):strdat[0];
	    String year = strdat[2];

	    String [] monthNames = new String[]{"January", "February", "March", "April", "May", "June",
		                  "July", "August", "September", "October", "November", "December"};

	    Date d = new Date();
		PDFcreator.getInstance().setYear(year);
		return (monthNames[d.getMonth()]+" "+day+","+year);
		
	}
	
	
	
	
	
	public  List<XWPFParagraph> getparam(XWPFDocument xdoc){
	       List<XWPFParagraph> paraList = xdoc.getParagraphs();
			System.out.println(paraList.size());
			for(XWPFParagraph para: paraList){
				
//				System.out.println(para.getText());
			}
			return paraList;
	}

	public  XWPFHeader getheader(XWPFDocument xdoc){
		
		XWPFHeaderFooterPolicy policy;
		XWPFHeader header = null;
		try {
			policy = new XWPFHeaderFooterPolicy(xdoc);
			    header = policy.getDefaultHeader();
//			   System.out.println(header.getAllPictures().get(0).getFileName()+System.lineSeparator());

		} catch (IOException | XmlException e) {
			// TODO Auto-generated catch block
			e.printStackTrace(); 
		}
		return header;

	}
	public  XWPFFooter getfooter(XWPFDocument xdoc){
		
		XWPFHeaderFooterPolicy policy;
		XWPFFooter footer = null;
		try {
			policy = new XWPFHeaderFooterPolicy(xdoc);
			   //read footer
			   footer = policy.getDefaultFooter();
			  
//			   System.out.println( footer.getText());
			   
		} catch (IOException | XmlException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return footer;
	}
	

	
	public  void creatdoc() throws FileNotFoundException, DocumentException{
		
		File useFolder = new File( System.getProperty("user.dir"), "PDF" );
		if(!useFolder.exists()){
			useFolder.mkdirs();
		}
		
		File [] files = new File [] {new File(useFolder.getAbsolutePath())};
		

		OutputStream file = new FileOutputStream(new File(useFolder.getAbsolutePath()+"\\"+PDFcreator.getInstance().getEmpid()+".pdf"));
		
		
	Font nf=new Font();
	
	 
	Paragraph parag;
		try{
			String img_Folder = new File(System.getProperty("user.dir"), "Files\\allstatelogo.png").getAbsolutePath();

			PDFcreator.getInstance().setDoc(new Document());
			Document doc = PDFcreator.getInstance().getDoc();
		PdfWriter PW = PdfWriter.getInstance(PDFcreator.getInstance().getDoc(), file);
		PDFencrypt(PW,PDFcreator.getInstance().getPassword(),"owner");
		PDFcreator.getInstance().getDoc().open();
//		getfooter(xdoc);
		
//		doc.addHeader(getfooter(xdoc).getText(), null);
		
		PDFcreator.getInstance().setImage(Image.getInstance(img_Folder));
		Image image = PDFcreator.getInstance().getImage();
		
        image.setAlignment(Image.MIDDLE);
//        image.setAbsolutePosition(450f, 450f);
//        image.scalePercent(0, 0);
        image.scaleToFit(350, 300);
//        image.setBackgroundColor(Font.COL);
        
  
//		    doc.add(new Paragraph ("Allstate Solutions Private limited"));
		    doc.add(image);
		List<XWPFParagraph> paraList = PDFcreator.getInstance().getDocFileParagraphs();
		int i=0;
		for(XWPFParagraph para: paraList){		

//			parag=new Paragraph();
			 
//			conditioncheck(para);
			doc.add(conditioncheck(para));
			String signature_path = new File(System.getProperty("user.dir"), "Files\\Signature.png").getAbsolutePath();	
			if(para.getText().startsWith(Allstate_logo)){
				image = Image.getInstance(signature_path);
				image.setAlignment(Image.ALIGN_LEFT);
				image.scaleToFit(100, 100);
//				image.setAlignment(Image.ALIGN_BOTTOM);
//				image.setSpacingBefore(50);
				doc.add(image);
			}
			

		}
//		image = Image.getInstance("C:/Users/gpree/Documents/HR/footer.png");
//		image.setAlignment(Image.MIDDLE);
//		image.scaleToFit(400, 400);
////		image.setAlignment(Image.ALIGN_BOTTOM);
//		image.setSpacingBefore(50);
//		doc.add(image);
		
		pg= new Paragraph (Allstate_Haeder,PDFcreator.getInstance().fontbold());
		pg.setAlignment(Element.ALIGN_CENTER);
		pg.setSpacingBefore(10);
		doc.add(pg);
		pg= new Paragraph (Allstate_Addressline1);
		pg.setAlignment(Element.ALIGN_CENTER);
		doc.add(pg);
		pg= new Paragraph (Allstate_Addressline2);
		pg.setAlignment(Element.ALIGN_CENTER);
		doc.add(pg);
		doc.close();
		PW.close();
		file.close();
		System.out.println("PDF Created - "+PDFcreator.getInstance().getEmpid()+".pdf");
		
		}catch(Exception e ){
			
		}

		
	}

	public  void PDFencrypt(PdfWriter writer, String PWD, String owner){
		try {
			writer.setEncryption(PWD.getBytes(), owner.getBytes(), writer.ALLOW_PRINTING, writer.ENCRYPTION_AES_128);
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public static Paragraph conditioncheck(XWPFParagraph para) throws DocumentException{
		
		Paragraph pg ;
		
		if(para.getText().startsWith(Name)){
			String[] name = para.getText().split(":");
			
//			Chunk pg1= new Chunk(name[0],PDFcreator.getInstance().fontbold());
//			
//			Chunk pg2= new Chunk(": ", PDFcreator.getInstance().fontbold());
//			
//			Chunk pg3= new Chunk(PDFcreator.getInstance().getName(),PDFcreator.getInstance().fontbold());
//			pg= new Paragraph();
//			pg.add(pg1);
//			pg.add(pg2);
//			pg.add(pg3);

String st= name[0]+"e\t\t: "+PDFcreator.getInstance().getName();
System.out.println(st);
pg= new Paragraph(st, PDFcreator.getInstance().fontbold());
//pg.setAlignment(Element.ALIGN_LEFT);
			
		pg.setAlignment(Element.ALIGN_LEFT);
		
		}else if(para.getText().startsWith(empId)){
          String[] empid = para.getText().split(":");
			
			Chunk pg1= new Chunk(empid[0],PDFcreator.getInstance().fontbold());
			
			Chunk pg2= new Chunk(": ", PDFcreator.getInstance().fontbold());
			
			Chunk pg3= new Chunk(PDFcreator.getInstance().getEmpid(),PDFcreator.getInstance().fontbold());
			
			pg= new Paragraph();
			pg.add(pg1);
			pg.add(pg2);
			pg.add(pg3);

			pg.setAlignment(Element.ALIGN_LEFT);
			
		}else if(para.getText().startsWith(Allstate_Delimiter)){
			
			pg= new Paragraph(para.getText(), PDFcreator.getInstance().fontbold());
			pg.setAlignment(Element.ALIGN_LEFT);
//			pg.setSpacingAfter(10);
			
/*			try {
				image = Image.getInstance("C:/Users/gpree/Documents/HR/Signature.png");
				image.setAlignment(Image.ALIGN_LEFT);
				image.scaleToFit(400, 400);
//				image.setAlignment(Image.ALIGN_BOTTOM);
				image.setSpacingBefore(50);
				doc.add(image);
			} catch (MalformedURLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
*/
		}else if(para.getText().startsWith(PDFcreator.getInstance().getpresentDate().split(" ")[0])){
			
			pg= new Paragraph(PDFcreator.getInstance().getDate(),PDFcreator.getInstance().fontbold());
			pg.setAlignment(Element.ALIGN_LEFT);
			pg.setSpacingAfter(10);
		
		}else if(para.getText().startsWith(Subject)){
			pg= new Paragraph(para.getText(),PDFcreator.getInstance().fontboldunderline());
			pg.setAlignment(Element.ALIGN_CENTER);
			
		pg.setSpacingAfter(10);
//			System.out.println(chunk.);
		}else if(para.getText().startsWith(AllstateDelimiter2)){
			 String[] firstname = para.getText().split("<<");
				
				Chunk pg1= new Chunk(firstname[0],PDFcreator.getInstance().fontbold());
				
				Chunk pg2= new Chunk(PDFcreator.getInstance().getFirstName()+",", PDFcreator.getInstance().fontbold());
				
				
				pg= new Paragraph();
				pg.add(pg1);
				pg.add(pg2);


			pg.setAlignment(Element.ALIGN_LEFT);
			pg.setSpacingAfter(10);
			
		}else if(para.getText().contains(Italic_Info)){
//			System.out.println(para.getText());
			String[] sarra = para.getText().split(Italic_Info);
			Chunk pg1= new Chunk(sarra[0]);
			Chunk pg2= new Chunk(Italic_Info, PDFcreator.getInstance().fontitalic());
			
			Chunk pg3= new Chunk(sarra[1]);
			pg= new Paragraph();
			pg.add(pg1);
			pg.add(pg2);
			pg.add(pg3);
//			pg= new Paragraph(para.getText());
			pg.setAlignment(Element.ALIGN_LEFT);
			pg.setSpacingAfter(10);
//			return comb;
		}
		else if(para.getText().contains("Rs. <<Amount>>/- (In Words:<<In Words>>)")){
			String[] amount = para.getText().split("Rs. <<Amount>>/- \\(In Words:<<In Words>>\\)");
			Chunk pg1= new Chunk(amount[0]);
			Chunk pg2 = new Chunk("Rs."+PDFcreator.getInstance().getAmount()+"/- (In Words:"+PDFcreator.getInstance().getAmount_words()+")",PDFcreator.getInstance().fontbold());
			Chunk pg3= new Chunk(amount[1]);
			pg= new Paragraph();

			pg.add(pg1);
			pg.add(pg2);
			pg.add(pg3);
//			pg= new Paragraph(para.getText());
			pg.setAlignment(Element.ALIGN_LEFT);
			pg.setSpacingAfter(10);

			
		}
		else if(para.getText().startsWith("__________")|para.getText().startsWith(Head_HR)|para.getText().startsWith(Head_HR_Desig)){
		
			pg= new Paragraph(para.getText(), PDFcreator.getInstance().fontbold());
			pg.setAlignment(Element.ALIGN_LEFT);			
		}else{
			pg= new Paragraph(para.getText());
			pg.setAlignment(Element.ALIGN_JUSTIFIED);
			pg.setSpacingAfter(10);
			
		}
		
		return pg;
	}

	public  Font fontbold(){
		Font boldFont = new Font(Font.FontFamily.HELVETICA, 12,  Font.BOLD);
		return boldFont;
	}
	public  Font fontitalic(){
		Font italicFont = new Font(Font.FontFamily.HELVETICA, 12,  Font.ITALIC);
		return italicFont;
	}
	
	public  Font fontboldunderline(){
//		Font boldunderlineFont = new Font(Font.FontFamily.HELVETICA, 12,  Font.BOLD | Font.UNDERLINE, BaseColor.BLACK);
		Font boldunderlineFont = new Font(Font.FontFamily.HELVETICA, 12,  Font.BOLD | Font.UNDERLINE);
		return boldunderlineFont;
	}
}
