package ExcelUtility;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.util.HashMap;

import org.apache.poi.hssf.usermodel.HSSFCell;
import org.apache.poi.hssf.usermodel.HSSFRow;
import org.apache.poi.hssf.usermodel.HSSFSheet;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.util.NumberToTextConverter;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelParser {

	private File [] files;
	private String KeyColumn;
	private String currentfile ;
	private Workbook workBook;
	private final String DOT = "\\.";
	private final String XLSx = "xlsx";
	private Boolean XlsxFlag = false;
	public ExcelParser(File [] Files,String KeyColumn){
	        this.files = Files;
	        this.KeyColumn = KeyColumn;

	}
	
	
	public void readExcelFiles(){
		try
		{
			
			for ( File filename : files )
			{
				XlsxFlag = filename.getName().split(DOT)[1].equalsIgnoreCase(XLSx)?true:false;
				this.currentfile= filename.getName().replaceAll(".xlsx", "");
				System.out.println("Reading "+currentfile+" with all the sheets");		

			    readExcelData( new FileInputStream( filename ) ,XlsxFlag);
			    
			    
			}
		}
		catch (FileNotFoundException file){
		
System.out.println("The File "+currentfile+" could not load due to exception"+file);		}
	
		
	}

	
	
	public void readExcelData(InputStream stream,Boolean xlsxFlag){
		Workbook workbook = null;
		ExcelData currentcol = null;
		
try{
	
	workbook = xlsxFlag?getXSSFWorkBook(stream):getHSSFWorkBook(stream);
	if(!(workbook==null)){
	for(int sheetnum=0;sheetnum<workbook.getNumberOfSheets();sheetnum++){
		String sheetName = workbook.getSheetName(sheetnum).trim();
		Sheet currentsheet = xlsxFlag?getXSSFCurrentSheet((XSSFWorkbook)workbook,sheetName):getXHSFCurrentSheet((HSSFWorkbook)workbook,sheetName);
	    if ( currentsheet == null ){
	        System.out.println("The sheet "+sheetName+"has an issue reading please check");
	        continue;
	    }
	    int checkkey = xlsxFlag?checkXSSFKeyColumn((XSSFSheet)currentsheet,KeyColumn):checkHSSFKeyColumn((HSSFSheet)currentsheet,KeyColumn);
	    if(checkkey==99999999){
	    throw new IllegalStateException( "Wrong keycolumn provided there is no column by"+ KeyColumn+"in the sheet"+sheetName);
	    }
	    else{
			Row firstRow = xlsxFlag?getXSSFrow((XSSFSheet)currentsheet,0):getHSSFrow((HSSFSheet)currentsheet,0);
			for (int i = 1; i <= currentsheet.getLastRowNum(); i++){
				Row currentRow =xlsxFlag? getXSSFrow((XSSFSheet)currentsheet,i):getHSSFrow((HSSFSheet)currentsheet,i);
				ExcelProvider.getInstance().addTestKey(xlsxFlag?getXSSFCellValue((XSSFCell)currentRow.getCell(checkkey)):getHSSFCellValue((HSSFCell)currentRow.getCell(checkkey)));
				 currentcol = xlsxFlag?new ExcelData(getXSSFCellValue((XSSFCell)currentRow.getCell(checkkey)),sheetName,currentfile):new ExcelData(getHSSFCellValue((HSSFCell)currentRow.getCell(checkkey)),sheetName,currentfile);

				for ( int x=0; x<firstRow.getLastCellNum(); x++ )
				{
				    String currentcolumn = xlsxFlag?getXSSFCellValue((XSSFCell) firstRow.getCell( x ) ):getHSSFCellValue((HSSFCell) firstRow.getCell( x ) );
				    if(currentcolumn==null && currentcolumn.isEmpty())
				    	break;
	                String currentcolumnval = xlsxFlag?getXSSFCellValue( (XSSFCell)currentRow.getCell( x ) ):getHSSFCellValue( (HSSFCell)currentRow.getCell( x ) );
	                
					
	                if ( currentcolumnval == null ||currentcolumnval.isEmpty())
	                	currentcolumnval = "";

	                currentcol.addcolval(currentcolumn,currentcolumnval);
					
                               
	              				}
				String keyval = xlsxFlag?getXSSFCellValue((XSSFCell)currentRow.getCell(checkkey)):getHSSFCellValue((HSSFCell)currentRow.getCell(checkkey));
				ExcelProvider.getInstance().addtestdata(keyval+"."+sheetName+"."+currentfile,currentcol);

			}

	    }
	    
	    

	}
	}

}
catch(Exception c){
	System.out.println("Error while tryng to read the sheets and respective row and column "+c);
}
	}
	
	
	/*
	 * 
	 */
			
	private Workbook getXSSFWorkBook(InputStream stream){
		try{
			return (Workbook)new XSSFWorkbook( stream );
			
			
		}
		catch(Exception e){	
		System.out.println("Error whle trying to open the  workbook"+"for "+currentfile+e);
	}
		return null;

	}
	/*
	 * 
	 */
			
	private Workbook getHSSFWorkBook(InputStream stream){
		try{
			return (Workbook)new HSSFWorkbook( stream );
			
			
		}
		catch(Exception e){	
		System.out.println("Error whle trying to open the  workbook"+"for "+currentfile+e);
	}
		return null;

	}
	/*
	 * 
	 */
	private Sheet getXSSFCurrentSheet(XSSFWorkbook currentbook,String sheetName){
		try{
			return currentbook.getSheet(sheetName);
			
		}
		catch(Exception d){
			System.out.println("Issue while trying to parse sheet"+sheetName+"*******Reason********"+d);
		}
		return null;	

	}
	
	/*
	 * 
	 */
	private Sheet getXHSFCurrentSheet(HSSFWorkbook currentbook,String sheetName){
		try{
			return currentbook.getSheet(sheetName);
			
		}
		catch(Exception d){
			System.out.println("Issue while trying to parse sheet"+sheetName+"*******Reason********"+d);
		}
		return null;	

	}
	 /*
	  * 
	  */
	
	private int checkXSSFKeyColumn(XSSFSheet sheet,String keycolumn){
		int col = 0;
		Row firstRow = getXSSFrow(sheet,0);
		
		for ( int i=0; i<firstRow.getLastCellNum(); i++ ){
			if(getXSSFCellValue((XSSFCell)firstRow.getCell(i)).trim().equalsIgnoreCase(keycolumn.trim())){
				return i;
			}
		}
return 99999999;
	}
	
	 /*
	  * 
	  */
	
	private int checkHSSFKeyColumn(HSSFSheet sheet,String keycolumn){
		int col = 0;
		Row firstRow = getHSSFrow(sheet,0);
		
		for ( int i=0; i<firstRow.getLastCellNum(); i++ ){
			if(getHSSFCellValue((HSSFCell)firstRow.getCell(i)).trim().equalsIgnoreCase(keycolumn.trim())){
				return i;
			}
		}
return 99999999;
	}
	
	/*
	 * 
	 */
	
	private Row getXSSFrow(XSSFSheet sheet,int i){
		try{
			return sheet.getRow(i);
		}
		catch(Exception c){
			System.out.println("error parsing the row at index"+i+" for sheet"+sheet.getSheetName());
		}
		return null;
	}
	
	/*
	 * 
	 */
	
	private Row getHSSFrow(HSSFSheet sheet,int i){
		try{
			return sheet.getRow(i);
		}
		catch(Exception c){
			System.out.println("error parsing the row at index"+i+" for sheet"+sheet.getSheetName());
		}
		return null;
	}
	/*
	 * 
	 */
	private String getXSSFCellValue( XSSFCell cell )
	{
		if (cell != null)
		{
			switch (cell.getCellType())
			{
				case XSSFCell.CELL_TYPE_BLANK:
					return null;
				case XSSFCell.CELL_TYPE_BOOLEAN:
					return String.valueOf( cell.getBooleanCellValue() );
				case XSSFCell.CELL_TYPE_NUMERIC:
					return NumberToTextConverter.toText( cell.getNumericCellValue() );
				case XSSFCell.CELL_TYPE_STRING:
					return cell.getRichStringCellValue().toString();
			}
		}
		return null;
	}
	
	/*
	 * 
	 */
	private String getHSSFCellValue( HSSFCell cell )
	{
		if (cell != null)
		{
			switch (cell.getCellType())
			{
				case HSSFCell.CELL_TYPE_BLANK:
					return null;
				case HSSFCell.CELL_TYPE_BOOLEAN:
					return String.valueOf( cell.getBooleanCellValue() );
				case HSSFCell.CELL_TYPE_NUMERIC:
					return NumberToTextConverter.toText( cell.getNumericCellValue() );
				case HSSFCell.CELL_TYPE_STRING:
					return cell.getRichStringCellValue().toString();
			}
		}
		return null;
	}
		
}
