package ExcelUtility;

import java.util.HashMap;

public class ExcelData {

	
	private String keyName;
	private String fileName;
	private String sheetname;
	private HashMap<String,String> colMap = new HashMap<String,String>();
	public ExcelData(String keyName,String fileName,String Sheetname){
		this.keyName =keyName;
		this.sheetname= Sheetname;
		this.fileName=fileName;
	}
	
	public String getkeyName(){
		return this.keyName;
	}
	
	public String getSheetName(){
		return this.sheetname;
	}
	
	public String getFileName(){
		return this.fileName;
	}
	
	public void addcolval(String key,String value){
		colMap.put(key, value);
	}
	
	public String getcolval(String key){
		return colMap.get(key);
	}
	
}
