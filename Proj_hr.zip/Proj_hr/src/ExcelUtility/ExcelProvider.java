package ExcelUtility;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class ExcelProvider {

	private static ExcelProvider InstanceProvider = new ExcelProvider();
	
	private LinkedHashMap<String,ExcelData> TestMap = new LinkedHashMap<String,ExcelData>();
	
	

	private ExcelParser Excelparser;
	private String testKey;
	private String keyName;
	private String FileName;
private String sheetName;
	private ExcelProvider(){
		
	}
	
	public static ExcelProvider getInstance(){
		return InstanceProvider;
	}
	
	public void setExcelProvider(ExcelParser parser){
		this.Excelparser = parser;
		Excelparser.readExcelFiles();
		
	}
	
	
	public void addTestKey(String test){
 		this.testKey  = test;
	}
	
	public String getTestKey(){
		return this.testKey;
	}
	
	public void addsheetName(String sheetname){
		this.sheetName = sheetname;
	}
	
	public String getSheetName(){
		return this.sheetName;
	}
	
	public void addKeyName(String keyname){
		this.keyName=keyname;
	}
	
	public String getKeyName(String keyname){
		return this.keyName;
	}
	
	public void addFileName(String fileName){
		this.FileName=fileName;
	}
	
	public String getFileNname(){
		return this.FileName;
	}
	
	
	public void addtestdata(String key,ExcelData data){ 
		this.TestMap.put(key, data);
	}
	
	public ExcelData gettestdata(String key,String sheetName,String FileName){
		return TestMap.get(key+"."+sheetName+"."+FileName);
	}
	
	public LinkedHashMap<String,ExcelData> getTestMap(){
		return this.TestMap;
	}
	
	public void setfileTest(String fileName,String keyName){
	this.keyName =  keyName;
	this.FileName = fileName;
	
	}
	
	
	public ExcelData getSheetData(String sheetname){
		this.sheetName = sheetname;
		return gettestdata(keyName,sheetName,FileName);
		
	}
}
