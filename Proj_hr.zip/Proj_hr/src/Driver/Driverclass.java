package Driver;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;

import ExcelUtility.ExcelData;
import ExcelUtility.ExcelParser;
import ExcelUtility.ExcelProvider;
import PDFCreator.PDFcreator;
import PDFUtility.PDFGenerator;
import PDFUtility.PDFHeaderFooter;
import PDFUtility.PDFProvider;
import WordDocUtility.WordParser;
import mail.MailGenerator;

public class Driverclass {
	
	private static final String IncrementorPromtion = "I";
		
	private static final String from_email = "AllstateIndiaCompensationandBenefits@allstate.com";
	private static final String from_emailname = "Allstate India Compensation and Benefits";
	private static String  fileName = null;
	private static String  Directoryname = null;
	public static String subject = "Compensation Revision Letter - April";
//	public static String subject = "Annual Incentive Payout - Performance Year";
	private static File useFolder;

	public static void main(String[] args) throws DocumentException, InvalidFormatException, IOException {
//		

//		String fileName = "C:/Users/gpree/Documents/HR/Salary_revision_letter.docx";
		if(IncrementorPromtion.startsWith("P")){
			Directoryname = "PDFPromtion";
			fileName = System.getProperty("user.dir")+"\\Files\\Promotion template - A-D - April 2016 - with Bonus.docx";	
			MailGenerator.getInstance().setIspromtion(true);
		}else if(IncrementorPromtion.startsWith("I")){
			fileName = System.getProperty("user.dir")+"\\Files\\Template - Salary revision letter - A-D - with Bonus.docx";
			MailGenerator.getInstance().setIspromtion(false);
			Directoryname = "PDFIncrement";
		}else if (IncrementorPromtion.startsWith("V")){
			fileName = System.getProperty("user.dir")+"\\Files\\Incentive_template.docx";
			MailGenerator.getInstance().setIsvariable(true);
			Directoryname = "PDFVariable";
		
		}
		
		PDFProvider.getInstance().setDate();;
		
		if(!(fileName.equals(null))||!(fileName.isEmpty())||!(fileName.equals(""))){
			
			WordParser.getInstance().setWordDocument(fileName);
			if(MailGenerator.getInstance().isIsvariable()){
				PDFProvider.getInstance().setSignaturePath("Files\\ChethanSignature.png");
			}else{
				PDFProvider.getInstance().setSignaturePath("Files\\SabuSignature.png");
			}
				PDFProvider.getInstance().setDirectory(Directoryname);

			//excel data path
			if((IncrementorPromtion.startsWith("I"))){
				PDFProvider.getInstance().setSignaturescalefit(150);
				useFolder = new File( System.getProperty("user.dir"), "Files\\Increment letter Breakup - Template.xlsx" );
			}else if(IncrementorPromtion.startsWith("P")){
				PDFProvider.getInstance().setSignaturescalefit(150);
				useFolder = new File( System.getProperty("user.dir"), "Files\\Promotion letter Breakup - Template.xlsx" );
			}else if(IncrementorPromtion.startsWith("V")){
				PDFProvider.getInstance().setSignaturescalefit(200);
				useFolder = new File( System.getProperty("user.dir"), "Files\\Annual Incentive Payout - Template.xlsx" );
			}
			
//			File useFolder = new File( System.getProperty("user.dir"), "Files\\Increment letter.xlsx" );
			File [] files = new File [] {new File(useFolder.getAbsolutePath())};
			PDFcreator.getInstance().setDate();
//			File wordFile = new File(System.getProperty("user.dir"),"Files\\VP_Template.docx");


//			PDFcreator.getInstance().setDocFileParagraphs(wordFile.getAbsolutePath());

			ExcelProvider.getInstance().setExcelProvider(new ExcelParser(files,"Employee ID"));
			if(IncrementorPromtion.equalsIgnoreCase("p")){
				MailGenerator.getInstance().setIspromtion(true);
				
			}else if(IncrementorPromtion.equalsIgnoreCase("V")){
				MailGenerator.getInstance().setIsvariable(true);
			}

				
			
			LinkedHashMap<String,ExcelData> data = 	ExcelProvider.getInstance().getTestMap();
			System.out.println("Number of Letters to be created "+ data.size());
			for(String key:data.keySet()){
				ExcelData exceldata = data.get(key);
				if(exceldata.getkeyName()!=null&&(!exceldata.getkeyName().isEmpty())&&(!exceldata.getkeyName().equalsIgnoreCase(" "))){
			

					PDFProvider.getInstance().setExceldata(data.get(key));
					PDFProvider.getInstance().setEmpid(exceldata.getcolval("Employee ID"));
			
					PDFProvider.getInstance().setDocument(new Document());
					PDFGenerator.getInstance().PDFGenerate();
					MailGenerator.getInstance().setEmailMap(exceldata.getcolval("Employee ID")+":"+exceldata.getcolval("First Name"), exceldata.getcolval("Email ID"));

		
		
				}
			}
			MailGenerator.setSubject(subject);
			StringBuffer sb = new StringBuffer();

			MailGenerator.getInstance().readmailformat();

			LinkedHashMap<String,String> email = MailGenerator.getInstance().getEmailMap();

			List<XWPFParagraph> generator = MailGenerator.getInstance().getEmailformat();
			for(XWPFParagraph para: generator){	
	        	System.out.println(para.getText());

	            if(para.getText().isEmpty()||para.getText().equals("")){
	            	sb.append(System.getProperty("line.separator")+System.getProperty("line.separator"));
	            }
	            else{
	            	sb.append(para.getText());
	            }
			}
			for(String key:email.keySet()){
				String name = key.split(":")[1];
				String empid =key.split(":")[0]; 
//		StringBuffer message = MailGenerator.getInstance().getMessagecontent();

				String Update_message = sb.toString().replace("<<Employee>>", name);
		
				MailGenerator.getInstance().sendEmail(from_email,from_emailname,email.get(key), MailGenerator.getSubject(), Update_message,new File(System.getProperty("user.dir")+"\\"+Directoryname+"\\"+ empid

+".pdf").getAbsolutePath(),empid+".pdf");


			}
		}else{
			System.out.println("Please provide the valid filename details..");
		}
		
		MailGenerator.getInstance().setIspromtion(false);
		System.out.println("Task completed");
	}
	
}
