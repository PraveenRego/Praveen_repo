package WordDocUtility;

import java.io.FileInputStream;
import java.io.IOException;
import java.util.LinkedHashMap;
import java.util.List;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.poi.xwpf.usermodel.XWPFParagraph;
import org.apache.poi.xwpf.usermodel.XWPFRun;
import org.apache.poi.xwpf.usermodel.XWPFTable;
import org.apache.poi.xwpf.usermodel.XWPFTableCell;
import org.apache.poi.xwpf.usermodel.XWPFTableRow;

//import com.allState.test.XWPFWordProvider;

public class XWPFWordProvider{

	private String fileName;
	private XWPFDocument document;
	private List<XWPFTable> tables;
	private List<XWPFParagraph> paragraphs;
	private List<XWPFRun> runs;
	
	public List<XWPFRun> getRuns() {
		return runs;
	}

	public void setRuns(XWPFParagraph paragraph) {
		this.runs = paragraph.getRuns();
	}

	private LinkedHashMap<String,XWPFTable> TableMap = new LinkedHashMap<String,XWPFTable>();
	
	public XWPFTable getTable(Integer tableIndex) {
		if (TableMap.isEmpty()||TableMap.size()<0) return null;
		return TableMap.get("Table"+Integer.toString(tableIndex));
	}

	public void setTableMap(List<XWPFTable> tables) {
		if (tables.isEmpty()||tables.size()<0) return;
		for (int i=0;i<tables.size();i++){
//			String tableindex= "Table"+i;
			TableMap.put("Table"+i, tables.get(i));
		}
	}

	public List<XWPFParagraph> getParagraphs() {
		return paragraphs;
	}

	public void setParagraphs(XWPFDocument document) {
		this.paragraphs = document.getParagraphs();
	}

	public List<XWPFTable> getTables() {
		return tables;
	}

	public void setTables(XWPFDocument document) {
		this.tables = document.getTables(); 
	}
	
	  public XWPFDocument getDocument() {
		return document;
	}

	public void setDocument() throws InvalidFormatException, IOException {		
		this.document = new XWPFDocument(OPCPackage.open(new FileInputStream(XWPFWordProvider.getInstance().getfileName())));		
	}

   public void setfileName(String filename) throws IOException{
    	this.fileName = filename;      
    }
   public String getfileName(){
	   	return	this.fileName;      
   }
    public int getTotalrows(XWPFTable table){
    	return table.getNumberOfRows();
    }
    
    public int getTotalcolumns(XWPFTableRow row){
    	return row.getTableCells().size();
    }
    
	private static final ThreadLocal<XWPFWordProvider> XWPFWordManager = new ThreadLocal<XWPFWordProvider>()
    {
        protected XWPFWordProvider initialValue() {
        	return new XWPFWordProvider();
        	
       }
    };
    public synchronized  static  XWPFWordProvider getInstance(){
        return XWPFWordManager.get();
      }

	private XWPFWordProvider(){};


public void readparagraph() throws IOException, InvalidFormatException{
//		int k;
/*	   int i=0;
	   
if (!(tables.size()<0)||!(tables.isEmpty())) {
   for(XWPFTable table: tables){
//    int rows = XWPFWordProvider.getInstance().getTotalrows(table);
    System.out.println("Number of rows "+XWPFWordProvider.getInstance().getTotalrows(XWPFWordProvider.getInstance().getTable(i)));
    System.out.println("Number of Columns "+XWPFWordProvider.getInstance().getTotalcolumns(XWPFWordProvider.getInstance().getTable(i).getRows().get(0)));
    for(XWPFTableRow row:table.getRows()){
    	for(XWPFTableCell cell: row.getTableCells()){
    		System.out.println(cell.getText());

    	}
    }
    
    i++;
   } 
  }*/
    
/*    List<XWPFParagraph> paragraphs = XWPFWordProvider.getInstance().getParagraphs();
    
    for (XWPFParagraph paragraph:paragraphs ){
    	XWPFWordProvider.getInstance().setRuns(paragraph);
    	for(XWPFRun run: XWPFWordProvider.getInstance().getRuns()){
    		System.out.println("isBold: "+run.isBold()+", "+"text Position = "+run.getText(run.getTextPosition()));
 
    	}
    }*/

}}

