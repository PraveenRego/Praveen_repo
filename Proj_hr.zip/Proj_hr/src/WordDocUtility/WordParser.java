package WordDocUtility;

import java.io.IOException;

import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.xwpf.usermodel.XWPFTable;

public class WordParser {
	private static final ThreadLocal<WordParser> WordManager = new ThreadLocal<WordParser>()
    {
        protected WordParser initialValue() {
        	return new WordParser();
        	
       }
    };
    public synchronized  static  WordParser getInstance(){
        return WordManager.get();
      }

	private WordParser(){};
	
    
    public void setWordDocument(String fileName) throws IOException, InvalidFormatException{
    	
    	XWPFWordProvider.getInstance().setfileName(fileName);
    	XWPFWordProvider.getInstance().setDocument();
    	XWPFWordProvider.getInstance().setParagraphs(XWPFWordProvider.getInstance().getDocument());
    	XWPFWordProvider.getInstance().setTables(XWPFWordProvider.getInstance().getDocument());
    	XWPFWordProvider.getInstance().setTableMap(XWPFWordProvider.getInstance().getTables());
    	
    	XWPFWordProvider.getInstance().readparagraph();
    
    }

}
