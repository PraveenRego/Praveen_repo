package mail;




import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Properties;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.activation.FileDataSource;
import javax.mail.Address;
import javax.mail.BodyPart;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;

import org.apache.poi.xwpf.usermodel.XWPFParagraph;

import PDFCreator.PDFcreator;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


	public class MailGenerator {
		private static final String fileformatname ="email_template";
		private List<XWPFParagraph> emailformat = new ArrayList();
		private LinkedHashMap<String,String> emailMap = new LinkedHashMap<String,String>();
		public String vptemplate = "email_template _Incentive";
private StringBuffer messagecontent ;
public static String subject;
public String fileformat_message;
public static String getSubject() {
	return subject;
}

public static void setSubject(String subject) {
	if (MailGenerator.getInstance().isIsvariable()){
	 int tempyear = Integer.valueOf(PDFcreator.getInstance().getYear()) -1;
	 MailGenerator.subject =  subject+" "+tempyear;
	}else{
	MailGenerator.subject =  subject+" "+PDFcreator.getInstance().getYear();
	}
}


private boolean ispromtion= false;
private boolean isvariable =false;

 public boolean isIsvariable() {
	return isvariable;
}

public void setIsvariable(boolean isvariable) {
	this.isvariable = isvariable;
}

		public boolean isIspromtion() {
	return ispromtion;
}

public void setIspromtion(boolean ispromtion) {
	this.ispromtion = ispromtion;
}

		public StringBuffer getMessagecontent() {
	return messagecontent;
}

public void setMessagecontent(StringBuffer sb) {
	this.messagecontent = messagecontent.append(sb);
}


//		public static String subject = "Annual Performance Incentive Letter - "+PDFcreator.getInstance().getYear();



			private static final ThreadLocal<MailGenerator> MailManager = new ThreadLocal<MailGenerator>()
		    {
		        protected MailGenerator initialValue() {
		        	return new MailGenerator();
		        	
		       }
		    };
		    public synchronized  static  MailGenerator getInstance(){
		        return MailManager.get();
		      }

		    private MailGenerator()
		    {
		    	
		    }

		/*public static void main(String[] args)  {
			List<String> emailList = new ArrayList<String>();
			emailList.add("gsriq@allstate.com");
			StringBuffer message = new StringBuffer();
			message.append("Execution has begun");
			try {
				MailGenerator.sendEmail("sbaln@allstate.com", emailList, "Jenkins state of execution" ,
						message.toString());
			} catch (AddressException myException) {
				// TODO Auto-generated catch block
				myException.printStackTrace();
			} catch (MessagingException myException) {
				// TODO Auto-generated catch block
				myException.printStackTrace();
			}
		}*/
		    
		    protected Log log = LogFactory.getLog( MailGenerator.class );

			public LinkedHashMap<String, String> getEmailMap() {
				return emailMap;
			}

			public void setEmailMap(String key ,String value) {
				if(!MailGenerator.getInstance().emailMap.containsKey(key)){
					MailGenerator.getInstance().emailMap.put(key, value);	
				}
			}
			
			public List<XWPFParagraph> getEmailformat() {
				return emailformat;
			}

			public void setEmailformat(List<XWPFParagraph> emailformat) {
				this.emailformat = emailformat;
			}


			
			public void readmailformat(){
				if(MailGenerator.getInstance().isIsvariable()){
				
					fileformat_message = vptemplate;
				}else{
				fileformat_message = MailGenerator.getInstance().isIspromtion()?fileformatname+"_P":fileformatname;
				}
				File useFolder = new File( System.getProperty("user.dir"), "Files" );
				
				if(!useFolder.exists()){
					useFolder.mkdirs();
				}
				
				File [] files = new File [] {new File(useFolder.getAbsolutePath())};

			 PDFcreator.getInstance().setDocFileParagraphs(useFolder.getAbsolutePath()+"\\"+fileformat_message+".docx");
			 
				MailGenerator.getInstance().setEmailformat(PDFcreator.getInstance().getDocFileParagraphs());
				  
			}

		public  void sendEmail1(final String fromEmail, List<String> toAddressList, String subject, StringBuffer message,String attachment){
try{
	File file = new File(attachment);
	Multipart multipart = new MimeMultipart();
			Properties properties = new Properties();
			properties.put("mail.smtp.host", "mail.allstate.com");
			Session session = Session.getDefaultInstance(properties);
			Message msg = new MimeMessage(session);
			MimeBodyPart messageBodyPart = new MimeBodyPart();
			msg.setFrom(new InternetAddress(fromEmail));
	         DataSource source = new FileDataSource(attachment);
			
			InternetAddress[] addressTo = new InternetAddress[toAddressList.size()];
			int counter = 0;
			for (String recipient : toAddressList) {
				addressTo[counter] = new InternetAddress(recipient);
				counter++;
			}
			messageBodyPart.setDataHandler(new DataHandler(source));
	         messageBodyPart.attachFile(file);
	         multipart.addBodyPart(messageBodyPart);
	         //multipart.addBodyPart(messageBodyPart);
			msg.setRecipients(Message.RecipientType.TO, addressTo);
			msg.addRecipient(Message.RecipientType.BCC, new InternetAddress(fromEmail));

			msg.setSubject(subject);
			msg.setSentDate(new Date());
			msg.setContent(message, "text/html; charset=utf-8");
	         //msg.setContent(multipart,message);

			

			Transport.send(msg);
			
			
}
catch(Exception c){
	System.out.println(c);
}
		}
		public  boolean sendEmail(final String fromEmail,final String from_emailname,String toAddressList, String subject, String message_Body,String fileName,String Name_file){
				 
            // Get system properties
            Properties properties = System.getProperties();
            // Setup mail server
          //  Properties.setProperty("mail.smtp.host", host);
            properties.setProperty("mail.smtp.host", "mail.allstate.com");
                  // Get the default Session object.
            Session session = Session.getDefaultInstance(properties);

            try{
               // Create a default MimeMessage object.
               MimeMessage message = new MimeMessage(session);
               // Set From: header field of the header.
              message.setFrom(new InternetAddress(fromEmail,from_emailname));
               // Set To: header field of the header.
               message.addRecipient(Message.RecipientType.TO,new InternetAddress(toAddressList));
               message.addRecipient(Message.RecipientType.BCC, new InternetAddress(fromEmail));
            //   message.addRecipient(Message.RecipientType.TO,new InternetAddress(to1));

               // Set Subject: header field
               message.setSubject(subject);

               // Create the message part 
               BodyPart messageBodyPart = new MimeBodyPart();

               // Fill the message
               messageBodyPart.setText(message_Body);

               // Create a multipar message
               Multipart multipart = new MimeMultipart();

               // Set text message part
               multipart.addBodyPart(messageBodyPart);

               // Part two is attachment
               messageBodyPart = new MimeBodyPart();
               
                      
               DataSource source = new FileDataSource(fileName);
               messageBodyPart.setDataHandler(new DataHandler(source));
               messageBodyPart.setFileName(Name_file);
               multipart.addBodyPart(messageBodyPart);

               // Send the complete message parts
               message.setContent(multipart );

               // Send message
               Transport.send(message);
               System.out.println("......Sent Email message successfully.... to "+toAddressList+" - "+Name_file);
            
            return true;
                  
            } catch (Exception myException) {
                  // TODO Auto-generated catch block
            	return false;
            }

			
			
				 }
		
		public void addMessageContent(StringBuffer sb){
			
			MailGenerator.getInstance().setMessagecontent(sb);
			
		}
		
	}


