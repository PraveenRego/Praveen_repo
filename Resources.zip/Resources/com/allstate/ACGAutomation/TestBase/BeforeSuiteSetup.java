package com.allstate.ACGAutomation.TestBase;

import java.io.File;
import java.io.IOException;
import java.util.logging.Level;

import org.testng.annotations.BeforeSuite;
import org.xframium.application.ApplicationRegistry;
import org.xframium.application.XMLApplicationProvider;
import org.xframium.artifact.ArtifactType;
import org.xframium.device.DeviceManager;
import org.xframium.device.cloud.CloudRegistry;
import org.xframium.device.cloud.XMLCloudProvider;
import org.xframium.device.data.DataManager;
import org.xframium.device.data.DataProvider;
import org.xframium.device.data.XMLDataProvider;
import org.xframium.device.data.DataProvider.DriverType;
import org.xframium.device.logging.ThreadedFileHandler;
import org.xframium.device.ng.AbstractSeleniumTest;
import org.xframium.gesture.GestureManager;
import org.xframium.gesture.factory.spi.PerfectoGestureFactory;
import org.xframium.page.PageManager;
import org.xframium.page.data.PageDataManager;
import org.xframium.page.data.provider.ExcelPageDataProvider;
import org.xframium.page.element.provider.ExcelElementProvider;
import org.xframium.page.listener.LoggingExecutionListener;
import org.xframium.spi.RunDetails;

public class BeforeSuiteSetup extends AbstractSeleniumTest {
	
	
	/*
	 * Used for basic setup
	 */
	/****************************************************************************************************************/
	// @BeforeSuite
	public void setupSuite(String resourceName,String tabNames) {

		log.info("Setup started..");
		final String IESettings = System.getProperty("user.dir")+ "\\Browsersettings\\IESettings.vbs";
		
		
		
		
		try {
//			Runtime.getRuntime().exec("cmd /c start " +KillProcess);
//			Robot r;
//			try {
//				r = new Robot();
//				r.keyPress(KeyEvent.VK_ENTER);
//			} catch (AWTException e) {
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
			
			Runtime.getRuntime().exec("CScript " +IESettings);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// =========================================================================================================
		// Passing a configuration file name indicates it is in the class path -
		// passing a File object indicates the file system
		CloudRegistry.instance().setCloudProvider(new XMLCloudProvider("Registry Files\\cloudRegistry.xml"));
		CloudRegistry.instance().setCloud("local");// for local executions
		// =========================================================================================================

		//
		// We are running in using the RemoteWebDriver with any device reserved
		// to me
		//
		// You can�t use the reserved handset validator in that case as you are
		// not going against a cloud: - Allen

		DataProvider dataProvider = new XMLDataProvider("Registry Files\\deviceRegistry.xml", DriverType.WEB);

		//
		// The factory for generating devices Gestures
		//
		GestureManager.instance().setGestureFactory(new PerfectoGestureFactory());

		//
		// Application - Passing a configuration file name indicates it is in
		// the class path - passing a File object indicates the file system
		//
		ApplicationRegistry.instance()
				.setApplicationProvider(new XMLApplicationProvider("Registry Files\\applicationRegistry.xml"));
//		ApplicationRegistry.instance().setAUT("FOCUS");
		ApplicationRegistry.instance().setAUT("GOOGLE");

		//
		// Optional parameters to automatically download reports upon completion
		//
		DataManager.instance().setReportFolder(new File("test-output"));
		DataManager.instance()
				.setAutomaticDownloads(new ArtifactType[] { ArtifactType.EXECUTION_REPORT_HTML,
						ArtifactType.FAILURE_SOURCE, ArtifactType.CONSOLE_LOG, ArtifactType.WCAG_REPORT,
						ArtifactType.EXECUTION_RECORD_CSV, ArtifactType.EXECUTION_RECORD_HTML });
		DataManager.instance().readData(dataProvider);

		PageManager.instance().setSiteName("Focus");
		PageManager.instance().registerExecutionListener(new LoggingExecutionListener());
		PageManager.instance().setElementProvider(
				new ExcelElementProvider("Object Repository\\OR_Focus.xlsx", "Focus"));

		// Load the data
		PageDataManager.instance()
				.setPageDataProvider(new ExcelPageDataProvider(resourceName,
						tabNames));

		//
		// Configure the thread logger to separate test case log files
		//
		ThreadedFileHandler threadedHandler = new ThreadedFileHandler();
		threadedHandler.configureHandler(Level.INFO);

		//
		// The RunDetail singleton can be registered to track all runs for the
		// consolidated output report
		DeviceManager.instance().addRunListener(RunDetails.instance());
//		DeviceManager.instance(
		String str[] = {"test09","def"};
//		DeviceManager.instance().
//		System.out.println(DataManager.instance().getTests()[0]);
		log.info("Setup done..");

	}

}
