package com.allstate.ACGAutomation.Utility;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.StaleElementReferenceException;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.xframium.device.ng.AbstractSeleniumTest;
import org.xframium.page.LocalAbstractPage;
import org.xframium.page.PageManager;
import org.xframium.page.StepStatus;
import org.xframium.page.data.PageData;
import org.xframium.page.data.PageDataManager;
import org.xframium.page.element.Element;
import org.xframium.page.element.Element.WAIT_FOR;

import com.google.common.base.CaseFormat;







/**
 * @Class Name: pomAction
 * @Description: This is the base class for actions on WebElements
 * @Creation Date: 25-Oct-2016
 * @author: Richard Shilesh
 * @Modified Date: 11-November-2016
 * @MOdified By: S.Sruthi
 */
public class WebAction extends LocalAbstractPage {

	PageDataManager dataManager = null;
	// public LocalAbstractPage lbs = null;
	LocalAbstractPage lbs = null;
	// AbstractPage abstractPage = null;
	DriverMethods driverMethods = null;
	// public String dataSetID = null;
	String dataSetID = null;
	AbstractSeleniumTest abstractSeleniumTest = null;

	public void initializePage() {
		driverMethods = new DriverMethods();
		dataManager = PageDataManager.instance();
	}

	public WebAction(LocalAbstractPage lbs, PageDataManager dataManager) {
		this.lbs = lbs;
		this.dataManager = dataManager;
		// abstractPage = lbs;
		driverMethods = new DriverMethods();
	}

	/**
	 * @param locator
	 *            : Element Identifier
	 * @param recordSheet
	 *            : PageData sheet name
	 * @param recordId
	 *            : parameter which defines which record to be picked
	 * @param columnName
	 *            : mapping to the Element Identifier
	 * @param logMessage
	 *            : Relevant log statement
	 * @throws Exception
	 */

	/*
	 * public void enterValueInTextBox(String locator, String recordSheet,
	 * String recordId, String columnName, String logMessage) throws Exception {
	 * 
	 * try { PageData pageData = dataManager.getPageData(recordSheet, recordId);
	 * 
	 * if (driverMethods.isDataPresent(pageData.getData(columnName))) {
	 * lbs.getElement(locator).waitFor(30, TimeUnit.SECONDS, WAIT_FOR.VISIBLE,
	 * ""); lbs.getElement(locator).setValue(pageData.getData(columnName)); }
	 * 
	 * if (logMessage.length() == 0 || logMessage.equalsIgnoreCase(""))
	 * log.info("Value entered in textbox is " + pageData.getData(columnName));
	 * else log.info(logMessage); } catch (Exception ex) {
	 * 
	 * PageManager.instance().addExecutionLog("", "", lbs.getPageName(),
	 * locator, "Failed to Enter Value in TextBox.", System.currentTimeMillis(),
	 * System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
	 * false, null); //throw new RuntimeException(ex.fillInStackTrace()); throw
	 * ex; } }
	 */

	/**
	 * @param locator
	 *            : Element Identifier
	 * @throws Exception
	 */

	public void CustomWait(int miliSeconds) {

		try {
			Thread.sleep(miliSeconds);
			Log.info("CustomWait",  "Script haulted for " + miliSeconds    ,"success");
		} catch (Exception e) {

			Log.error("CustomWait",  e.toString()   ,"fail");
		}
	}

	public void enterValueInTextBoxAndPressTAB(String locator, String text, String strField) throws Exception {
		if(!text.trim().equalsIgnoreCase("")){
			try {
				int i = 0 ;
				lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
				//                waitForObjectToBecomeVisible(locator, strField);
				int a ;
				//                lbs.getElement(locator).waitForVisible(10, TimeUnit.SECONDS);

				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				driverMethods.scrollingToElementofAPage(ele);
				//                ele.click();
				//                if(ele.getAttribute("value").trim()!=null)
				//                {
				//ele.clear();
				//                }
				//                try{
				//                      ele.clear();
				//                }catch(Exception e)
				//                {June       
				//
				//                }
				//                ele.sendKeys(text + Keys.TAB);
				//                ele.sendKeys(Keys.TAB);
				//                lbs.getElement(locator).click();
				text=text.trim();
				while(!text.trim().equalsIgnoreCase(lbs.getElement(locator).getAttribute("value").trim())){

					lbs.getElement(locator).setValue(text+Keys.TAB);
					++i;
					if(i>1)
					{
						System.out.println("lbs.getElement(locator).getAttribute('value').trim(): " + lbs.getElement(locator).getAttribute("value").trim());
						System.out.println("text.trim(): " + text.trim());
					}
					//                        lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
					if(i==25)
						break;

					//                        if(lbs.getElement(locator).getAttribute("value").trim().equalsIgnoreCase(text.trim()))
					//                        {
					//                              break;
					//                        }

					//                            CustomWait(500);
				}

				//                                  lbs.getElement(locator).setValue(text+Keys.TAB);
				//                lbs.getElement(locator).click();
				//                lbs.getElement(locator).setValue("" +Keys.TAB);
				log.info("Value entered in textbox is " + text);
				Log.info("enterValueInTextBoxAndPressTAB", "Value" + text + "entered inside textbox " + strField, "Done");

			} 
			catch(StaleElementReferenceException se)
			{

			}
			catch (Exception ex) {
				if(!ex.toString().contains("Element is no longer valid")){
					Log.error("enterValueInTextBoxAndPressTAB", ex.toString(), "Fail");
					PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator,
							"Failed to Enter Value in TextBox.", System.currentTimeMillis(), System.currentTimeMillis(),
							StepStatus.FAILURE, "", null, 0, "Failed", false, null);
					// throw new RuntimeException(ex.fillInStackTrace());
					throw ex;
				}

			}
		}
	}


	public void enterValueInTextBoxAndPressTAB2(String locator, String text, String strField) throws Exception {
		if(!text.trim().equalsIgnoreCase("")){
			try {

				lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
				//			waitForObjectToBecomeVisible(locator, strField);
				int a ;
				//			lbs.getElement(locator).waitForVisible(10, TimeUnit.SECONDS);
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				//			ele.click();
				//			if(ele.getAttribute("value").trim()!=null)
				//			{
				//ele.clear();
				//			}
				//			try{
				//				ele.clear();
				//			}catch(Exception e)
				//			{June 	
				//
				//			}
				//			ele.sendKeys(text + Keys.TAB);
				//			ele.sendKeys(Keys.TAB);
				//			lbs.getElement(locator).click();
				text=text.trim();
				//				do{

				lbs.getElement(locator).setValue(text+Keys.TAB);
				//					CustomWait(500);
				//				}while(!lbs.getElement(locator).getAttribute("value").trim().equalsIgnoreCase(text.trim()));

				//						lbs.getElement(locator).setValue(text+Keys.TAB);
				//			lbs.getElement(locator).click();
				//			lbs.getElement(locator).setValue("" +Keys.TAB);
				log.info("Value entered in textbox is " + text);
				Log.info("enterValueInTextBoxAndPressTAB", "Value" + text + "entered inside textbox " + strField, "Done");

			} catch (Exception ex) {
				Log.error("enterValueInTextBoxAndPressTAB", ex.toString(), "Fail");
				PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator,
						"Failed to Enter Value in TextBox.", System.currentTimeMillis(), System.currentTimeMillis(),
						StepStatus.FAILURE, "", null, 0, "Failed", false, null);
				// throw new RuntimeException(ex.fillInStackTrace());
				throw ex;

			}
		}
	}

	public void enterValueInTextBoxAndPressTABCheck(String locator, String text, String strField) throws Exception {
		if(!text.trim().equalsIgnoreCase("")){
			try {

				lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
				//					waitForObjectToBecomeVisible(locator, strField);
				int a ;
				//			lbs.getElement(locator).waitForVisible(10, TimeUnit.SECONDS);
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				//			ele.click();
				//			if(ele.getAttribute("value").trim()!=null)
				//			{
				//ele.clear();
				//			}
				//					try{
				//						ele.clear();
				//					}catch(Exception e)
				//					{
				//
				//					}
				//					ele.sendKeys(text + Keys.TAB);
				//			ele.sendKeys(Keys.TAB);
				//			lbs.getElement(locator).click();
				do{

					lbs.getElement(locator).setValue(text+Keys.TAB);
					CustomWait(1000);
				}while(!lbs.getElement(locator).getAttribute("value").trim().equalsIgnoreCase(text.trim()));

				//			lbs.getElement(locator).click();
				//			lbs.getElement(locator).setValue("" +Keys.TAB);
				log.info("Value entered in textbox is " + text);
				Log.info("enterValueInTextBoxAndPressTAB", "Value" + text + "entered inside textbox " + strField, "Done");

			} catch (Exception ex) {
				Log.error("enterValueInTextBoxAndPressTAB", ex.toString(), "Fail");
				PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator,
						"Failed to Enter Value in TextBox.", System.currentTimeMillis(), System.currentTimeMillis(),
						StepStatus.FAILURE, "", null, 0, "Failed", false, null);
				// throw new RuntimeException(ex.fillInStackTrace());
				throw ex;

			}
		}
	}

	public void enterValueInTextBoxAndPressTABClickCheck(String locator, String text, String strField) throws Exception {
		if(!text.trim().equalsIgnoreCase("")){
			try {

				lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
				//					waitForObjectToBecomeVisible(locator, strField);
				int a ;
				//			lbs.getElement(locator).waitForVisible(10, TimeUnit.SECONDS);
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				driverMethods.scrollingToElementofAPage(ele);
				//			ele.click();
				//			if(ele.getAttribute("value").trim()!=null)
				//			{
				//ele.clear();
				//			}
				//					try{
				//						ele.clear();
				//					}catch(Exception e)
				//					{
				//
				//					}
				//					ele.sendKeys(text + Keys.TAB);
				//			ele.sendKeys(Keys.TAB);
				//			lbs.getElement(locator).click();
				do{
					lbs.getElement(locator).click();
					lbs.getElement(locator).setValue(text+Keys.TAB);
					CustomWait(1000);
				}while(!lbs.getElement(locator).getAttribute("value").trim().equalsIgnoreCase(text.trim()));

				//			lbs.getElement(locator).click();
				//			lbs.getElement(locator).setValue("" +Keys.TAB);
				log.info("Value entered in textbox is " + text);
				Log.info("enterValueInTextBoxAndPressTAB", "Value" + text + "entered inside textbox " + strField, "Done");

			} catch (Exception ex) {
				Log.error("enterValueInTextBoxAndPressTAB", ex.toString(), "Fail");
				PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator,
						"Failed to Enter Value in TextBox.", System.currentTimeMillis(), System.currentTimeMillis(),
						StepStatus.FAILURE, "", null, 0, "Failed", false, null);
				// throw new RuntimeException(ex.fillInStackTrace());
				throw ex;

			}
		}
	}


	public void enterValueInTextBoxAndPressTAB1(String locator, String text, String strField) throws Exception {
		if(!text.trim().equalsIgnoreCase("")){
			try {

				lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
				//					waitForObjectToBecomeVisible(locator, strField);

				//			lbs.getElement(locator).waitForVisible(10, TimeUnit.SECONDS);
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				//			ele.click();
				//			if(ele.getAttribute("value").trim()!=null)
				//			{
				//ele.clear();
				//			}

				ele.sendKeys(text + Keys.TAB);
				//			ele.sendKeys(Keys.TAB);
				//			lbs.getElement(locator).click();
				//			lbs.getElement(locator).setValue(text+Keys.TAB);
				//			lbs.getElement(locator).click();
				//			lbs.getElement(locator).setValue("" +Keys.TAB);
				log.info("Value entered in textbox is " + text);
				Log.info("enterValueInTextBoxAndPressTAB", "Value" + text + "entered inside textbox " + strField, "Done");

			} catch (Exception ex) {
				Log.error("enterValueInTextBoxAndPressTAB1", ex.toString(), "Fail");
				PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator,
						"Failed to Enter Value in TextBox.", System.currentTimeMillis(), System.currentTimeMillis(),
						StepStatus.FAILURE, "", null, 0, "Failed", false, null);
				// throw new RuntimeException(ex.fillInStackTrace());
				throw ex;

			}
		}
	}

	public void clearTextBox(String locator,  String strField) throws Exception {

		try {

			lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
			//					waitForObjectToBecomeVisible(locator, strField);
			int a ;
			//			lbs.getElement(locator).waitForVisible(10, TimeUnit.SECONDS);
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			try{
				ele.clear();
			}
			catch(Exception e)
			{

			}





			Log.info("clearTextBox", "textbox" + strField + "cleared ", "Done");

		} catch (Exception ex) {
			Log.error("clearTextBox", ex.toString(), "Fail");

			throw ex;

		}
	}


	public void selectTab(String locator)
	{
		int a ;

		try {
			CustomWait(1500);
			while(!lbs.getElement(locator).getAttribute("class").equalsIgnoreCase("gwt-TreeItem gwt-TreeItem-selected"))
			{
				lbs.getElement(locator).click();
				Log.info("selectTab", "Tab" + locator + " clicked " , "Done");
			}
		} catch (Exception ex) {
			Log.error("selectTab", ex.toString(), "Fail");

			// throw new RuntimeException(ex.fillInStackTrace());
			throw ex;

		}

	}

	public void setCheckBox(String locator, String text ,  String strField) throws Exception {
		try{
			if(text.trim().equalsIgnoreCase("ON"))
			{

				int a ;
				int f=0;
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				driverMethods.scrollingToElementofAPage(ele);
				while(!ele.findElement(By.xpath("..")).getAttribute("class").trim().equalsIgnoreCase("field f_editable� checkbox cbEditable cbEditValYes"))
				{
					ele.click();

					f=1;
				}
				if(f==1)
					Log.info("setCheckBoxON", strField + " checkbox checked" , "Done");
				else
				{
					Log.info("setCheckBoxON", strField + " checkbox was already checked" , "Done");
				}


			}
			else
			{
				int a ;
				int f=0;
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				while(ele.isSelected())
				{
					ele.click();
					f=1;
				}
				if(f==1)
					Log.info("setCheckBoxON", strField + " checkbox un-checked" , "Done");
				else
				{
					Log.info("setCheckBoxON", strField + " checkbox was already un-checked" , "Done");
				}


			}

		} catch (Exception ex1) {
			Log.error("setCheckBoxON", ex1.toString(), "Fail");
			// throw new RuntimeException(ex.fillInStackTrace());
			throw ex1;

		}

	}

	public void setCheckBox1(String locator, String text ,  String strField) throws Exception {
		try{
			if(text.trim().equalsIgnoreCase("ON"))
			{

				int a ;
				int f=0;
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				driverMethods.scrollingToElementofAPage(ele);
				while(!ele.findElement(By.xpath("..")).getAttribute("class").trim().endsWith("Yes"))
				{
					ele.click();

					f=1;
				}
				if(f==1)
					Log.info("setCheckBoxON", strField + " checkbox checked" , "Done");
				else
				{
					Log.info("setCheckBoxON", strField + " checkbox was already checked" , "Done");
				}


			}
			else
			{
				int a ;
				int f=0;
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				while(ele.isSelected())
				{
					ele.click();
					f=1;
				}
				if(f==1)
					Log.info("setCheckBoxON", strField + " checkbox un-checked" , "Done");
				else
				{
					Log.info("setCheckBoxON", strField + " checkbox was already un-checked" , "Done");
				}


			}

		} catch (Exception ex1) {
			Log.error("setCheckBoxON", ex1.toString(), "Fail");
			// throw new RuntimeException(ex.fillInStackTrace());
			throw ex1;

		}

	}


	public void validateCheckBoxSelection(String locator,  String strField) throws Exception {
		try{


			int a ;
			int f=0;
			//			lbs.getElement(locator).waitFor(20, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			driverMethods.scrollingToElementofAPage(ele);
			if(ele.isSelected())
			{
				Log.pass("validateCheckBoxSelection", "checkbox " + locator + " is selected.", driverMethods.takeScreenshot());
				Log.pass("validateCheckBoxSelection", "checkbox " + locator + " is selected.");
			}
			else
			{
				Log.fail("validateCheckBoxSelection", "checkbox " + locator + " is not selected.", "Fail" ,driverMethods.takeScreenshot());
				Log.fail("validateCheckBoxSelection", "checkbox " + locator + " is not selected." , "Fail");
				throw new Exception("checkbox " + locator + " is not selected.");
			}

		} catch (Exception ex1) {
			Log.error("validateCheckBoxSelection", ex1.toString(), "Fail");
			// throw new RuntimeException(ex.fillInStackTrace());
			throw ex1;

		}

	}

	public String getText (String locator , String strField)
	{
		WebElement ele = (WebElement) lbs.getElement(locator).getNative();

		Log.info("getText", "innertext: " + ele.getText() + " inside web element " + strField, "success");
		return ele.getText();

	}

	public void validateLabelText(String locator , String strVal2) throws Exception
	{
		lbs.getElement(locator).waitFor(60, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");
		WebElement ele = (WebElement) lbs.getElement(locator).getNative();
		driverMethods.scrollingToElementofAPage(ele);
		String strVal1= ele.getText().trim();
		//		String strVal2 = ExcelHandling.getCellData(strField).trim() ;
		if(strVal1.equalsIgnoreCase(strVal2))
		{
			Log.pass("validateLabelText", "Expected value: " + strVal2 + " Actual Value: " + strVal1 + " for field " +  locator);
		}
		else
		{
			Log.fail("validateLabelText", "Expected value: " + strVal2 + " Actual Value: " + strVal1 + " for field " +  locator , "Fail");
			//			throw new Exception("Expected value: " + strVal1 + " Actual Value: " + strVal2 + " for field " +  strField );
		}
	}

	public void validateLabelText1(String locator , String strVal2) throws Exception
	{
		if(!strVal2.trim().equalsIgnoreCase("")){
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			driverMethods.scrollingToElementofAPage(ele);
			String strVal1= ele.getText().trim();
			//		String strVal2 = ExcelHandling.getCellData(strField).trim() ;
			if(strVal1.equalsIgnoreCase(strVal2))
			{
				Log.pass("validateLabelText", "Expected value: " + strVal2 + " Actual Value: " + strVal1 + " for field " +  locator );
				Log.pass("validateLabelText", "Expected value: " + strVal2 + " Actual Value: " + strVal1 + " for field " +  locator , driverMethods.takeScreenshot());

			}
			else
			{
				Log.fail("validateLabelText", "Expected value: " + strVal2 + " Actual Value: " + strVal1 + " for field " +  locator , "Fail");
				Log.fail("validateLabelText", "Expected value: " + strVal2 + " Actual Value: " + strVal1 + " for field " +  locator , "Fail", driverMethods.takeScreenshot());
				//			throw new Exception("Expected value: " + strVal1 + " Actual Value: " + strVal2 + " for field " +  strField );
			}
		}
	}
	public void validateLabelLength(String locator , String strVal2) throws Exception 
	{
		if(!strVal2.trim().equalsIgnoreCase("")){
			lbs.getElement(locator).waitFor(60, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			String strVal1= ele.getText().trim();
			if(strVal1.length()==Integer.parseInt(strVal2))
			{
				Log.pass("validateLabelText", "Expected Label length: " + strVal2 + " Actual Label length: " + strVal1.length() + " for field " +  locator);
			}
			else
			{
				Log.fail("validateLabelText", "Expected Label length:: " + strVal2 + " Actual Label length: " + strVal1.length() + " for field " +  locator , "Fail");
				//			throw new Exception("Expected value: " + strVal1 + " Actual Value: " + strVal2 + " for field " +  strField );
			}
		}
	}

	public String getValue (String locator , String strField)
	{
		int a ;
		WebElement ele = (WebElement) lbs.getElement(locator).getNative();

		Log.info("getValue", "innertext: " + ele.getText() + " inside web element " + strField, "success");
		return ele.getAttribute("value");

	}
	
	

	public void validateClass (String locator , String strValue , String strField) throws Exception
	{
		int a ;
		lbs.getElement(locator).waitFor(20, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
		WebElement ele = (WebElement) lbs.getElement(locator).getNative();
		System.out.println(ele.getAttribute("class").trim());
		//		System.out.println(lbs.getElement(locator).getClass().toString());
		//		System.out.println(lbs.getElement(locator).getValue().trim());
		driverMethods.scrollingToElementofAPage(ele);
		if(ele.getAttribute("class").trim().trim().equalsIgnoreCase(strValue))
		{
			Log.pass("validateValue", "checkbox " + locator + " is selected.", driverMethods.takeScreenshot());
			Log.pass("validateValue", "checkbox " + locator + " is selected.");
		}
		else
		{
			Log.fail("validateValue", "checkbox " + locator + " is not selected.", "Fail" ,driverMethods.takeScreenshot());
			Log.fail("validateValue", "checkbox " + locator + " is not selected." , "Fail");
			throw new Exception("checkbox " + locator + " is not selected.");
		}


	}



	// -------------------------------DropDowns------------------------------------------------------
	/**
	 * @param locator
	 *            : Element Identifier
	 * @param recordSheet
	 *            : PageData sheet name
	 * @param recordId
	 *            : parameter which defines which record to be picked
	 * @param columnName
	 *            : mapping to the Element Identifier
	 * @param logMessage
	 *            : relavant log statement
	 * @throws Exception
	 */
	/*
	 * public void selectFromDropDown(String locator, String recordSheet, String
	 * recordId, String columnName, String logMessage) throws Exception {
	 * 
	 * try { dataManager = PageDataManager.instance(); PageData pageData =
	 * dataManager.getPageData(recordSheet, recordId);
	 * lbs.getElement(locator).waitFor(120, TimeUnit.SECONDS, WAIT_FOR.VISIBLE,
	 * ""); if (driverMethods.isDataPresent(pageData.getData(columnName))) {
	 * lbs.getElement(locator).setValue(pageData.getData(columnName)); } if
	 * (logMessage.length() == 0 || logMessage.equalsIgnoreCase("")) log.info(
	 * "Value set in DropDown is " + pageData.getData(columnName)); else
	 * log.info(logMessage); } catch (Exception ex) {
	 * 
	 * PageManager.instance().addExecutionLog("", "", lbs.getPageName(),
	 * locator, "Failed to Select value From DropDown",
	 * System.currentTimeMillis(), System.currentTimeMillis(),
	 * StepStatus.FAILURE, "", null, 0, "Failed", false, null); throw new
	 * RuntimeException(ex.fillInStackTrace());
	 * 
	 * } }
	 */

	/**
	 * @param locator
	 *            : Element Identifier
	 * @throws Exception
	 */
	public void selectFromDropDown(String locator) throws Exception {

		try {

			String recordSheet = lbs.getClass().getSimpleName().replace("Impl", "").trim();
			System.out.println("Sheet name is " + recordSheet);
			String columnName = CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, locator.split("_", 2)[1]);
			System.out.println("Column name is " + columnName);
			// selectFromDropDown(locator, recordSheet, dataSetID, recordColumn,
			// "");
			PageData pageData = dataManager.getPageData(recordSheet);
			// System.out.println(pageData);
			// lbs.getElement(locator).waitFor(120, TimeUnit.SECONDS,
			// WAIT_FOR.VISIBLE, "");
			// if (driverMethods.isDataPresent(pageData.getData(columnName))) {
			lbs.getElement(locator).setValue(pageData.getData(columnName));
			System.out.println("Value is" + pageData.getData(columnName));
			// }

			log.info("Value set in DropDown is " + pageData.getData(columnName));

		} catch (Exception ex) {

			// throw new RuntimeException(ex.fillInStackTrace());

		}
	}

	// ================================Radio Button
	// Click==================================================
	/**
	 * @param locator
	 *            : Element Identifier
	 * @param logMessage
	 *            : relavant log statement
	 * @throws Exception
	 */
	public void clickRadioButton(String locator, String logMessage) throws Exception {

		try {
			lbs.getElement(locator).waitFor(60, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");

			lbs.getElement(locator).click();

			if (logMessage.length() == 0 || logMessage.equalsIgnoreCase(""))
				log.info("Selected " + locator + " in " + lbs.getPageName() + " screen");
			else
				log.info(logMessage);
		} catch (Exception ex) {

			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator, "Unable to select Radio Button",
					System.currentTimeMillis(), System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
					false, null);
			throw new RuntimeException(ex.fillInStackTrace());
		}
	}

	/**
	 * @param locator
	 *            : Element Identifier
	 * @throws Exception
	 */
	public void selectRadioButton(String locator) throws Exception {

		try {
			lbs.getElement(locator).waitFor(60, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");

			clickRadioButton(locator, "");

		} catch (Exception ex) {

			throw new RuntimeException(ex.fillInStackTrace());
		}
	}

	// ====================================ClickCheckbox=================================================

	/**
	 * @param locator
	 *            : Element Identifier
	 * @param logMessage
	 *            : relavant log statement
	 * @throws Exception
	 */
	/*
	 * public void clickCheckBox(String locator, String logMessage) throws
	 * Exception {
	 * 
	 * try { lbs.getElement(locator).waitFor(60, TimeUnit.SECONDS,
	 * WAIT_FOR.VISIBLE, "");
	 * 
	 * lbs.getElement(locator).click();
	 * 
	 * if (logMessage.length() == 0 || logMessage.equalsIgnoreCase(""))
	 * log.info("Selected " + locator + " in " + lbs.getPageName() + " screen");
	 * else log.info(logMessage); } catch (Exception ex) {
	 * 
	 * PageManager.instance().addExecutionLog("", "", lbs.getPageName(),
	 * locator, "Click Failed", System.currentTimeMillis(),
	 * System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
	 * false, null); throw new RuntimeException(ex.fillInStackTrace()); } }
	 */

	/**
	 * @param locator
	 *            : Element Identifier
	 * @throws Exception
	 */
	public void clickCheckBox(String locator) throws Exception {

		try {
			// lbs.getElement(locator).waitFor(60, TimeUnit.SECONDS,
			// WAIT_FOR.VISIBLE, "");
			String recordSheet = lbs.getClass().getSimpleName().replace("Impl", "").trim();
			System.out.println("Sheet name is " + recordSheet);
			String columnName = CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, locator.split("_", 2)[1]);
			System.out.println("Column name is " + columnName);
			// selectFromDropDown(locator, recordSheet, dataSetID, recordColumn,
			// "");
			PageData pageData = dataManager.getPageData(recordSheet);
			// System.out.println(pageData);
			// lbs.getElement(locator).waitFor(120, TimeUnit.SECONDS,
			// WAIT_FOR.VISIBLE, "");
			// if (driverMethods.isDataPresent(pageData.getData(columnName))) {
			String value = pageData.getData(columnName);
			System.out.println("Value is" + value);
			if (value.equalsIgnoreCase("Check")) {
				// write code to verify if it is selected
				lbs.getElement(locator).click();

			}

			// }

			// clickRadioButton(locator, "");
			log.info("Selected " + locator + " in " + lbs.getPageName() + " screen");

		} catch (Exception ex) {

			// throw new RuntimeException(ex.fillInStackTrace());
		}
	}

	// =====================================Click
	// Link========================================================
	/**
	 * @param locator
	 *            : Element Identifier
	 * @param logMessage
	 *            : relavant log statement
	 * @throws Exception
	 */
	public void clickLink(String locator, String logMessage) throws Exception {

		try {
			lbs.getElement(locator).waitFor(60, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");

			lbs.getElement(locator).click();

			if (logMessage.length() == 0 || logMessage.equalsIgnoreCase(""))
				log.info("Click on " + locator + " in " + lbs.getPageName() + " screen");
			else
				log.info(logMessage);
		} catch (Exception ex) {

			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator,
					"Unable to click on the hyperlink", System.currentTimeMillis(), System.currentTimeMillis(),
					StepStatus.FAILURE, "", null, 0, "Failed", false, null);
			throw new RuntimeException(ex.fillInStackTrace());
		}
	}

	/**
	 * @param locator
	 *            : Element Identifier
	 * @throws Exception
	 */
	public void clickLink(String locator) throws Exception {

		try {
			lbs.getElement(locator).waitFor(60, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");
			// Thread.sleep(2000);
			clickLink(locator, "");

		} catch (Exception ex) {

			throw new RuntimeException(ex.fillInStackTrace());
		}
	}

	// =====================================ButtonClick========================================================
	/**
	 * @param locator
	 *            : Element Identifier
	 * @param logMessage
	 *            : relavant log statement
	 * @throws Exception
	 */
	public void clickButton(String locator, String logMessage, String strfield) throws Exception {

		try {
			lbs.getElement(locator).waitFor(60, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");

			lbs.getElement(locator).click();

			if (logMessage.length() == 0 || logMessage.equalsIgnoreCase(""))
				log.info("Click on " + locator + " in " + lbs.getPageName() + " screen");
			else
				log.info(logMessage);
		} catch (Exception ex) {

			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator, "Unable to click button",
					System.currentTimeMillis(), System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
					false, null);
			throw new RuntimeException(ex.fillInStackTrace());
		}
	}

	/**
	 * @param locator
	 *            : Element Identifier
	 * @throws Exception
	 */

	public void clickButton(String locator, String strField) throws Exception {


		try {
			int a ;
			//                waitForObjectToBecomeVisible(locator, strField);

			lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");

			System.out.println("Button argument passed as locator is:" + locator);
			//    lbs.getElement(locator).waitFor(20, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");
			//                lbs.getElement(locator).moveTo();

			if("radio".equalsIgnoreCase(lbs.getElement(locator).getAttribute("type")))
			{
				clickRadioButtonCheck(locator, strField);
			}
			else
			{
				lbs.getElement(locator).click();

				log.info("Clicked " + locator + " in " + lbs.getPageName() + " screen");
				Log.info("clickButton", "Elemennt" + strField + " clicked", "Done");
			}
		} catch (Exception ex) {
			Log.error("clickButton", ex.toString(), "Error");
			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator, "Unable to click Button",
					System.currentTimeMillis(), System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
					false, null);
			throw ex;
		}

	}

	public void validateElementDisabled(String locator, String strField) throws Exception {


		try {
			int a ;
			//                waitForObjectToBecomeVisible(locator, strField);

			lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			driverMethods.scrollingToElementofAPage(ele);
			if(!ele.isEnabled())
			{
				Log.pass("validateElementDisabled", "Elemennt" + strField + " is disabled");
			}
			else
			{
				Log.fail("validateElementDisabled", "Elemennt" + strField + " is enabled",driverMethods.takeScreenshot() );
			}

		} catch (Exception ex) {
			Log.error("clickButton", ex.toString(), "Error");
			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator, "Unable to click Button",
					System.currentTimeMillis(), System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
					false, null);
			throw ex;
		}

	}


	public void clickTab(String locator, String strField) throws Exception {


		try {
			int a ;
			//			waitForObjectToBecomeVisible(locator, strField);

			lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");

			int i=0 ;
			System.out.println("Button argument passed as locator is:" + locator);
			//	lbs.getElement(locator).waitFor(20, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");
			//			lbs.getElement(locator).moveTo();
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			while(!ele.getAttribute("class").equalsIgnoreCase("instncNtbkTabActive")){
				lbs.getElement(locator).click();
				lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
				++i;
				if(i==25)
					break;
			}

			log.info("Clicked " + locator + " in " + lbs.getPageName() + " screen");
			Log.info("clickButton", "Elemennt" + strField + " clicked", "Done");
		} catch (Exception ex) {
			Log.error("clickTab", ex.toString(), "Error");
			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator, "Unable to click Button",
					System.currentTimeMillis(), System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
					false, null);
			throw ex;
		}

	}


	public void clickRadioButtonCheck(String locator, String strField) throws Exception {


		try {
			int a ;
			//			waitForObjectToBecomeVisible(locator, strField);
			//			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");

			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			driverMethods.scrollingToElementofAPage(ele);

			System.out.println("Button argument passed as locator is:" + locator);
			//	lbs.getElement(locator).waitFor(20, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");
			while(!ele.isSelected()){
				//				lbs.getElement(locator).moveTo();
				lbs.getElement(locator).click();
			}

			log.info("Clicked " + locator + " in " + lbs.getPageName() + " screen");
			Log.info("clickButton", "Elemennt" + strField + " clicked", "Done");
		} catch (Exception ex) {
			Log.error("clickButton", ex.toString(), "Error");
			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator, "Unable to click Button",
					System.currentTimeMillis(), System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
					false, null);
			throw ex;
		}

	}

	public void clickButtonIfExists(String locator, String strField)  {


		try {
			int a ;
			//			waitForObjectToBecomeVisible(locator, strField);
			CustomWait(1000);
			//			lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
			System.out.println("Button argument passed as locator is:" + locator);
			//	lbs.getElement(locator).waitFor(20, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "")
			if(lbs.getElement(locator).getCount()!=0){
				if(lbs.getElement(locator).isPresent()){
					if(lbs.getElement(locator).isVisible()){
						WebElement ele = (WebElement) lbs.getElement(locator).getNative();
						driverMethods.scrollingToElementofAPage(ele);
						lbs.getElement(locator).click();
						log.info("Clicked " + locator + " in " + lbs.getPageName() + " screen");
						Log.info("clickButtonIfExists", "Elemennt" + strField + " clicked", "Done");
					}
				}
			}
		} catch (Exception ex) {
			Log.info("clickButtonIfExists: error overlooked", ex.toString(), "Done");
			//			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator, "Unable to click Button",
			//					System.currentTimeMillis(), System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
			//					false, null);

		}

	}


	public boolean validateObjectExist(String locator, String strField) throws Exception {
		if(lbs.getElement(locator).getCount()!=0)
		{
			if(lbs.getElement(locator).isVisible()){
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				driverMethods.scrollingToElementofAPage(ele);
				return true ;
			}
			else
				return false;
		}
		else
		{
			return false ;
		}
	}


	public void validateObjectExist1(String locator, String strField) throws Exception {
		if(lbs.getElement(locator).getCount()!=0)
		{
			if(lbs.getElement(locator).isVisible())
			{
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				driverMethods.scrollingToElementofAPage(ele);
				Log.pass("validateObjectExist", "Elemennt" + strField + " is present");
			}
			else
				Log.fail("validateObjectExist", "Elemennt" + strField + " is absent","fail");
		}
		else
		{
			Log.fail("validateObjectExist", "Elemennt" + strField + " is absent","fail");
		}
	}

	public void validateObjectExistNegative(String locator, String strField) throws Exception {
		if(lbs.getElement(locator).getCount()!=0)
		{
			if(lbs.getElement(locator).isVisible())
			{
				WebElement ele = (WebElement) lbs.getElement(locator).getNative();
				driverMethods.scrollingToElementofAPage(ele);
				Log.fail("validateObjectExistNegative", "Elemennt" + strField + " is present", "fail");
			}
			else
				Log.pass("validateObjectExistNegative", "Elemennt" + strField + " is present");
		}
		else
		{
			Log.pass("validateObjectExistNegative", "Elemennt" + strField + " is absent");
		}
	}

	public void validateObjectValue(String locator, String strValue,String strField) throws Exception {
		//int a ;
		//		locator= "RenewalCycleField";
		lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
		//		System.out.println(lbs.getElement(locator).getAttribute("value"));
		//		System.out.println(lbs.getElement(locator).getValue());
		//		System.out.println(lbs.getElement(locator).getAttribute("class"));
		//		System.out.println(lbs.getElement(locator).getValue());
		if(lbs.getElement(locator).getAttribute("value").trim().equalsIgnoreCase(strValue.trim()))
		{
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			driverMethods.scrollingToElementofAPage(ele);
			Log.pass("validateObjectValue", "Expected Value:" + strValue + " . Actual Value: " + lbs.getElement(locator).getAttribute("value").trim());
		}
		else
		{
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			driverMethods.scrollingToElementofAPage(ele);
			Log.fail("validateObjectValue", "Expected Value:" + strValue + " . Actual Value: " + lbs.getElement(locator).getAttribute("value").trim(),"fail");
	//		throw new Exception ("");
		}

	}

	public void validateObjectText(String locator, String strValue,String strField) throws Exception {
		//int a ;
		//		locator= "RenewalCycleField";
		lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
		//		System.out.println(lbs.getElement(locator).getAttribute("value"));
		//		System.out.println(lbs.getElement(locator).getValue());
		//		System.out.println(lbs.getElement(locator).getAttribute("class"));
		//		System.out.println(lbs.getElement(locator).getValue());
		if(lbs.getElement(locator).getValue().trim().equalsIgnoreCase(strValue.trim()))
		{
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			driverMethods.scrollingToElementofAPage(ele);
			Log.pass("validateObjectText", "Expected Value:" + strValue + " . Actual Value: " + lbs.getElement(locator).getValue().trim());
			driverMethods.takeScreenshot();
		}
		else
		{
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			driverMethods.scrollingToElementofAPage(ele);
			Log.fail("validateObjectText", "Expected Value:" + strValue + " . Actual Value: " + lbs.getElement(locator).getValue().trim(),"fail");
			driverMethods.takeScreenshot();
			//throw new Exception ("");
		}

	}



	public void clickButton1(String locator, String strField) throws Exception {


		try {
			//			waitForObjectToBecomeVisible(locator, strField);
			//			lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");
			System.out.println("Button argument passed as locator is:" + locator);
			//	lbs.getElement(locator).waitFor(20, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");

			//			lbs.getElement(locator).click();
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();

			driverMethods.scrollingToElementofAPage(ele);
			ele.click();

			log.info("Clicked " + locator + " in " + lbs.getPageName() + " screen");
			Log.info("clickButton", "Elemennt" + strField + " clicked", "Done");
		} catch (Exception ex) {
			Log.error("clickButton", ex.toString(), "Error");
			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator, "Unable to click Button",
					System.currentTimeMillis(), System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
					false, null);
			throw ex;
		}

	}



	public void pressButton(String locator, String strField) throws Exception {


		try {
			lbs.getElement(locator).waitFor(10, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
			System.out.println("Button argument passed as locator is:" + locator);
			//	lbs.getElement(locator).waitFor(20, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");
			WebElement ele = (WebElement) lbs.getElement(locator).getNative();
			driverMethods.scrollingToElementofAPage(ele);
			lbs.getElement(locator).press();

			log.info("pressButton " + locator + " in " + lbs.getPageName() + " screen");
			Log.info("pressButton", "Elemennt" + strField + " pressed", "Done");
		} catch (Exception ex) {
			Log.error("pressButton", ex.toString(), "Error");
			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator, "Unable to press Button",
					System.currentTimeMillis(), System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
					false, null);
			throw ex;
		}

	}

	public void test(String locator1, String locator2, String strField) throws Exception {
		int a ;

		try {

			do
			{
				lbs.getElement(locator1).press();
				CustomWait(500);
				System.out.println(locator1 + " clicked");
				Log.info("test", "Clicked " + locator1 + " in " + lbs.getPageName() + " screen", "Done");
			}while(lbs.getElement(locator2).getCount()==0);

			Log.info("test", "Elemennt" + strField + " clicked", "Done");
		} catch (Exception ex) {
			Log.error("test", ex.toString(), "Error");
			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator1, "Unable to click Button",
					System.currentTimeMillis(), System.currentTimeMillis(), StepStatus.FAILURE, "", null, 0, "Failed",
					false, null);
			throw ex;
		}

	}

	public void waitForObjectToBecomeInvisible(String locator , String strField) throws Exception  {
		try{
			lbs.getElement(locator).waitFor(120, TimeUnit.SECONDS, WAIT_FOR.INVISIBLE, "");

			Log.info("waitForObjectToBecomeInvisible", "Waited for object " + strField + " to become invisible.", "Done");
		}
		catch(Exception e)
		{
			Log.error("waitForObjectToBecomeInvisible", e.toString(), "Error");
			throw e ;
		}
	}

	public void waitForObjectToBecomeVisible(String locator , String strField) throws Exception  {
		try{
			lbs.getElement(locator).waitFor(300, TimeUnit.SECONDS, WAIT_FOR.CLICKABLE, "");
			//			lbs.getElement(locator).moveTo();
			Log.info("waitForObjectToBecomeVisible", "Waited for object " + strField + " to become visible.", "Done");
		}
		catch(Exception e)
		{
			Log.error("waitForObjectToBecomeVisible", e.toString(), "Error");
			throw e ;
		}
	}

	public void waitForObjectToBecomeVisible1(String locator , String strField) throws Exception  {
		try{
			lbs.getElement(locator).waitFor(180, TimeUnit.SECONDS, WAIT_FOR.VISIBLE, "");
			//			lbs.getElement(locator).moveTo();
			Log.info("waitForObjectToBecomeVisible", "Waited for object " + strField + " to become visible.", "Done");
		}
		catch(Exception e)
		{
			Log.error("waitForObjectToBecomeVisible", e.toString(), "Error");
			throw e ;
		}
	}

	// ==============================MutiSelect=====================================

	/**
	 * @param locator
	 *            : Element Identifier
	 * @param recordSheet
	 *            : PageData sheet name
	 * @param recordId
	 *            : parameter which defines which record to be picked
	 * @param columnName
	 *            : mapping to the Element Identifier
	 * @param logMessage
	 *            : relavant log statement
	 * @throws Exception
	 */
	public void selectMultipleValuesFromDropdown(String locator, String recordSheet, String recordId, String columnName,
			String logMessage) {
		log.debug("Begin of  DriverMethod.actionMouseOver()");
		try {
			dataManager = PageDataManager.instance();
			PageData pageData = dataManager.getPageData(recordSheet, recordId);
			String text;
			String values = pageData.getData(columnName);
			String data[] = values.split(",");
			Select sel = new Select((WebElement) lbs.getElement(locator).getNative());
			List<WebElement> options = sel.getOptions();
			Actions actions = new Actions(driverMethods.getDriver());
			sel.deselectAll();
			actions.keyDown(Keys.CONTROL).build().perform();
			for (String str : data) {
				for (WebElement opt : options) {
					text = opt.getText().trim();
					if (text.equalsIgnoreCase(str)) {
						opt.click();
						break;
					}
				}
			}
			actions.keyUp(Keys.CONTROL).build().perform();

			if (logMessage.length() == 0 || logMessage.equalsIgnoreCase(""))
				log.info("Value set in DropDown is " + pageData.getData(columnName));
			else
				log.info(logMessage);
		} catch (Exception ex) {

			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), locator,
					"Unable to select value from Dropdown.", System.currentTimeMillis(), System.currentTimeMillis(),
					StepStatus.FAILURE, "", null, 0, "Failed", false, null);
			throw new RuntimeException(ex.fillInStackTrace());
		}

	}


	/**
	 * @param locator
	 *            : Element Identifier
	 * @throws Exception
	 */
	public void selectMultipleValuesFromDropdown(String locator) {
		log.debug("Begin of  DriverMethod.actionMouseOver()");
		try {
			String recordSheet = lbs.getClass().getSimpleName();
			String recordColumn = CaseFormat.UPPER_UNDERSCORE.to(CaseFormat.LOWER_CAMEL, locator.split("_", 2)[1]);
			selectMultipleValuesFromDropdown(locator, recordSheet, dataSetID, recordColumn, "");

		} catch (Exception ex) {

			throw new RuntimeException(ex.fillInStackTrace());
		}

	}

	/**
	 * @param locator
	 */
	public void waitFor(String locator) {
		try {

			lbs.getElement(locator).waitForVisible(30, TimeUnit.SECONDS);

		} catch (Exception ex) {

			log.error("Failed");
			throw new RuntimeException(ex.fillInStackTrace());
		}
	}

	public void addExecutionLog(String status, Long startTime, String methodState) {
		if (status.equalsIgnoreCase("PASSED")) {
			log.info("ClassName : " + lbs.getPageName() + ", Method Name :" + methodState + "--- > End");
			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), methodState, "Method Executed",
					System.currentTimeMillis(), System.currentTimeMillis() - startTime, StepStatus.SUCCESS, "", null, 0,
					"Passed", false, null);
		} else {
			PageManager.instance().addExecutionLog("", "", lbs.getPageName(), methodState, "Method Failed",
					System.currentTimeMillis(), System.currentTimeMillis() - startTime, StepStatus.FAILURE, "", null, 0,
					"Failed", false, null);
		}

	}

	public Element getWebElement(String element) {

		return lbs.getElement(element);
	}

}
