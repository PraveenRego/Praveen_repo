package com.allstate.ACGAutomation.Utility;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @Class Name: CommonMethods
 * @Description: Having reusable common methods
 * @Creation Date: 18-July-2016
 * @author: Mohita Bisaria
 * @Modified By: Mohita Bisaria
 * @MOdified Date: 18-July-2016
 *
 */
public class CommonMethods {

	/**
	 * @Description : StackTraceElement[] to get method list as param
	 * @param StackTraceElement[]
	 * @return String
	 */
	public static String getCurrentMethodName(StackTraceElement[] stacktrace) {

		return stacktrace[1].getMethodName();

	}

	/**
	 * Split the values for checkbox from page data seperated by comma.
	 * 
	 * @param values
	 * @return List<String>
	 */
	public static List<String> splitChecboxValues(String values) {

		List<String> listValues = null;

		try {

			listValues = Arrays.asList(values.trim().split(","));
			System.out.println(listValues);

		} catch (Exception e) {
			e.printStackTrace();
		}

		return listValues;

	}

	public static void main(String args[]) {
		List<String> listValues = splitChecboxValues("mon , Tue , wed");
	}

public String getSystemDate(){
		
		DateFormat df = new SimpleDateFormat("MM/d/yyyy");
		// Instantiate a Date object
	      Date date = new Date();

	     //String currentDate = df.format(date);
	      return df.format(date);
	     
	     
	}
	
}
