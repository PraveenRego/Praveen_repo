package com.allstate.ACGAutomation.Utility;

import java.io.File;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.FluentWait;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.xframium.device.ConnectedDevice;
import org.xframium.device.factory.DeviceWebDriver;
import org.xframium.device.ng.AbstractSeleniumTest;
import org.xframium.page.element.Element;
import org.xframium.page.element.Element.WAIT_FOR;
import org.xframium.spi.Device;
import org.apache.commons.io.FileUtils;
import org.jboss.netty.util.internal.SystemPropertyUtil;
import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.NoAlertPresentException;
import org.openqa.selenium.NoSuchElementException;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.UnhandledAlertException;

/**
 * @Class Name: DriverMethods
 * @Description: Having reusable driver methods
 * @Creation Date: 18-July-2016
 * @author: Mohita Bisaria
 * @Modified By: S.Sruthi
 * @MOdified Date:
 * 
 */
public class DriverMethods extends AbstractSeleniumTest {

	private WebDriver webDriver = null;

	public Wait<WebDriver> wait  = new FluentWait<WebDriver>(getWebDriver())
			// Wait for the condition
			.withTimeout(20, TimeUnit.SECONDS)
			// which to check for the condition with interval of 2 seconds.
			.pollingEvery(1, TimeUnit.SECONDS)
			// Which will ignore the NoSuchElementException
			.ignoring(NoSuchElementException.class);
	
	public DriverMethods()
	{
		getWebDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}
	
	/*
	 * Method to open any URL
	 */
	public void openURL(String url) {
		try {
			//	Log.info("***** In method 'openURL()' for URL: " + url + " *****");

			getWebDriver().get(url);
			getWebDriver().manage().timeouts().pageLoadTimeout(10, TimeUnit.SECONDS);
			getWebDriver().manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
			maximizeWindow();

			//	Log.info("***** Exiting method 'openURL()' for URL: " + url + " *****");
		} catch (Exception ex) {
			//			throw ex;

			getWebDriver().get(url);
		}
	}
	
	
	public void click(String strXPATH)
	{
		try{
//			 strXATH = "" ;
//			waitForObjectBeClickable(strXPATH,strXPATH);
//			waitForObjectBeClickable(strXPATH,strXPATH);
		getWebDriver().findElement(By.xpath(strXPATH)).click();
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}
	}

	public void validateCheckBoxSelection(String strXPATH,  String strField) throws Exception {
		try{


			int a ;
			waitForObjectBeClickable(strXPATH, strField);
			WebElement ele = getWebDriver().findElement(By.xpath(strXPATH));
			scrollingToElementofAPage(ele);
			if(ele.isSelected())
			{
				Log.pass("validateCheckBoxSelection", "checkbox " + strXPATH + " is selected.", takeScreenshot());
				Log.pass("validateCheckBoxSelection", "checkbox " + strXPATH + " is selected.");
			}
			else
			{
				Log.fail("validateCheckBoxSelection", "checkbox " + strXPATH + " is not selected.", "Fail" ,takeScreenshot());
				Log.fail("validateCheckBoxSelection", "checkbox " + strXPATH + " is selected." , "Fail");
			}

		} catch (Exception ex1) {
			Log.error("validateCheckBoxSelection", ex1.toString(), "Fail");
			// throw new RuntimeException(ex.fillInStackTrace());
			throw ex1;

		}

	}
	
	

	public void switchToBrowserWithTitle(String browserTitle,String strField) {	
		try{
			Thread.sleep(4000);
			WebDriver driver = getWebDriver();
			int flag=0 ;				
			int count = 0 ;

			Set<String> hwnds = driver.getWindowHandles();
			for(String hwnd:hwnds){
				driver.switchTo().window(hwnd); 
				driver.manage().window().maximize();
				Thread.sleep(1200);
				if(driver.getTitle().equalsIgnoreCase(browserTitle.trim())) {
					flag=1 ;
					break;
				}
			}
			if (flag==1)
			{
				System.out.println("browser switching passed");
			}
			else
			{
				System.out.println("browser switching failed");
			}	
		}
		catch(Exception e)
		{

		}

	}

	public void closePrevBrowser() {	
		try{
			Thread.sleep(2000);

			int flag=0 ;				
			int count = 0 ;

			Set<String> hwnds =  getWebDriver().getWindowHandles();
			for(String hwnd:hwnds){
				getWebDriver().switchTo().window(hwnd); 
				//				 System.out.println(getWebDriver().getCurrentUrl()); 
				getWebDriver().manage().window().maximize();
				Thread.sleep(1500);
				if( !getWebDriver().getCurrentUrl().contains("about:blank")) {
					getWebDriver().close();
					flag=1 ;
					//					break;
				}
			}
			if (flag==1)
			{
				System.out.println("browser switching passed");
			}
			else
			{
				System.out.println("browser switching failed");
			}	
		}
		catch(Exception e)
		{

		}

	}

	public void switchToNewBrowser() {	
		try{
			Thread.sleep(2000);

			int flag=0 ;				
			int count = 0 ;

			Set<String> hwnds =  getWebDriver().getWindowHandles();
			for(String hwnd:hwnds){
				getWebDriver().switchTo().window(hwnd); 
				getWebDriver().manage().window().maximize();
				Thread.sleep(1500);
				if( getWebDriver().getCurrentUrl().contains("about:blank")) {
					getWebDriver().manage().window().maximize();
					flag=1 ;
					break;
				}

			}
			if (flag==1)
			{
				System.out.println("browser switching passed");
			}
			else
			{
				System.out.println("browser switching failed");
			}	
		}
		catch(Exception e)
		{

		}

	}

	public void openBrowser()
	{
		//int a ;
		System.out.println();
		try{
			((JavascriptExecutor)getWebDriver()).executeScript("window.open();");
			//		 switchToNewBrowser();
			//		 getWebDriver().get("https://tstfocus.allstate.ca/signon.htm");
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}
	}

	/*
	 * Method for maximizing a window
	 */
	public void maximizeWindow() {
		try {
			getWebDriver().manage().window().maximize();
		} catch (Exception ex) {
			throw ex;
			////Log.error(e);
			// e.getMessage();
		}
	}



	/*
	 * Method to wait for PageLoad
	 */
	public void WaitForWindowToLoad(int WaitTime) {
		try {
			//	Log.info("Method 'WaitForWindowToLoad' starts here");
			getWebDriver().manage().timeouts().pageLoadTimeout(WaitTime, TimeUnit.SECONDS);
		} catch (Exception ex) {
			throw ex;
		}
	}

	public void waitForTitle(String strtitle) {
		try{
			if (wait.until(ExpectedConditions.titleIs(strtitle.trim())) != null) {
				Log.info("waitForTitle",  "Title ." + strtitle + " is  present." ,"success");
			} else {
				Log.fail("waitForTitle",  "Title ." + strtitle + " is  absent." ,"fail");
			}
		}
		catch(Exception e)
		{		
			Log.info("waitForTitle",  "Title ." + strtitle + " is  present." ,"success");
			Log.error("waitForTitle",  e.toString() ,"fail");
			throw e;
		}
	}
	public void invokeURL  (String strURL) throws Exception
	{
		try{
			Thread.sleep(1200);
			getWebDriver().get(strURL);


		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}


	public void switchFrame(String strID) throws Exception
	{
		try{
			Thread.sleep(1500);
			getWebDriver().switchTo().frame(strID);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}

	public void switchDefaultContent() throws Exception
	{
		try{
			Thread.sleep(1500);
			getWebDriver().switchTo().defaultContent();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}

	public void removeCoverage(String strCoverage)
	{
		if(!strCoverage.trim().equalsIgnoreCase("")){
			try{
				scrollingToElementofAPage(getWebDriver().findElement(By.xpath("//*[text()='"+strCoverage+"']/following::*[text()='Remove'][1]")));
				waitForObjectBeClickable("//*[text()='"+strCoverage+"']/following::*[text()='Remove'][1]" , strCoverage);
				getWebDriver().findElement(By.xpath("//*[text()='"+strCoverage+"']/following::*[text()='Remove'][1]")).click();
			}
			catch(Exception e)
			{
				throw e;
			}
		}
	}

	public void clickNoRadioBtns(String strValue)
	{
		try{


			//	int a ;
			if(strValue.trim().equalsIgnoreCase("Yes"))
			{
				int size = getWebDriver().findElements(By.xpath("//input[@type='radio'][@value='N']")).size() ;
				for(int i=1 ; i<=size ; i++)
				{
					if(getWebDriver().findElement(By.xpath("(//input[@type='radio'][@value='N'])["+i+"]")).isDisplayed())
					{
						getWebDriver().findElement(By.xpath("(//input[@type='radio'][@value='N'])["+i+"]")).click();
						if(getWebDriver().findElements(By.xpath("//*[@class='gwt-TreeItem gwt-TreeItem-selected'][@id='FTABMemo']")).size()>0)
						{
							if(getWebDriver().findElement(By.xpath("//*[@class='gwt-TreeItem gwt-TreeItem-selected'][@id='FTABMemo']")).isDisplayed())
							{
								getWebDriver().findElement(By.xpath("//*[@id='FTABReferenceQuestions']")).click();
							}
						}
					}
				}
			}
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}
	}

	public void addCoverage(String strCoverage) throws Exception
	{
		if(!strCoverage.trim().equalsIgnoreCase("")){
			try{

				if(getWebDriver().findElements(By.xpath("//*[text()='"+strCoverage+"']/parent::tr//input")).size()>0)
				{

					getWebDriver().findElement(By.xpath("//*[text()='"+strCoverage+"']/parent::tr//input")).click();				
				}
				else
				{
					getWebDriver().findElement(By.xpath("//*[text()='"+strCoverage+"']/parent::tr//td[1]")).click();
					Thread.sleep(1200);					
					getWebDriver().findElement(By.xpath("//*[text()='"+strCoverage+"']/parent::tr//input")).click();	
				}
			}
			catch(Exception e)
			{
				throw e;
			}
		}
	}


	public void addCoverageLocation(String strCoverage) throws Exception
	{
		if(!strCoverage.trim().equalsIgnoreCase("")){
			while(true){

				try{
					if(getWebDriver().findElements(By.xpath("//*[text()='"+strCoverage+"']/parent::tr//input")).size()>0)
					{
						getWebDriver().findElement(By.xpath("//*[text()='"+strCoverage+"']/parent::tr//input")).click();	
						Thread.sleep(1200);
						return ;
					}
					else if(getWebDriver().findElements(By.xpath("//*[text()='"+strCoverage+"']/parent::tr//td[1]")).size()>0)
					{
						getWebDriver().findElement(By.xpath("//*[text()='"+strCoverage+"']/parent::tr//td[1]")).click();
						Thread.sleep(1200);
						getWebDriver().findElement(By.xpath("//*[text()='"+strCoverage+"']/parent::tr//input")).click();
						Thread.sleep(1200);
						return ;
					}

					if(getWebDriver().findElements(By.xpath("(//td[text()='Next >>'])[2]")).size()>0)
					{
						if(getWebDriver().findElement(By.xpath("(//td[text()='Next >>'])[2]")).isDisplayed())
						{
							getWebDriver().findElement(By.xpath("(//td[text()='Next >>'])[2]")).click();
						}
					}
					else
					{
						return ;
					}
				}
				catch(Exception e)
				{
					throw e;
				}
			}
		}
	}

	public boolean validateNI(int n)
	{
		//		try{
		String str = "";
		str = getWebDriver().findElement(By.xpath("//table[@id='AccountingMPPSchedule']//td[1][text()='"+n+"']/parent::tr//td[4]")).getText();
		if(str.trim().equalsIgnoreCase("Yes"))
		{
			getWebDriver().findElement(By.xpath("//table[@id='AccountingMPPSchedule']//td[1][text()='"+n+"']/parent::tr//td[4]")).click();
			return true;
		}
		else
		{
			return false ;
		}

		//		catch(Exception e)
		//		{
		//			e.printStackTrace();
		//			return false ;
		//		}
	}


	public void click(String strXPATH, String strField)
	{
		waitForObjectBeClickable(strXPATH, strField);
		getWebDriver().findElement(By.xpath(strXPATH)).click();
	}

	public void type(String strXPATH, String strText) throws Exception
	{
		if(!strText.trim().equalsIgnoreCase("")){
			//		waitForObjectBeClickable(strXPATH, strXPATH);
			//		getWebDriver().findElement(By.xpath(strXPATH)).clear();
			getWebDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
			try{
				if(!getWebDriver().findElement(By.xpath(strXPATH)).getAttribute("value").trim().equalsIgnoreCase(strText)){
					while(!getWebDriver().findElement(By.xpath(strXPATH)).getAttribute("value").trim().equalsIgnoreCase("")){
						getWebDriver().findElement(By.xpath(strXPATH)).sendKeys(Keys.BACK_SPACE);
						Thread.sleep(500);
					}
					getWebDriver().findElement(By.xpath(strXPATH)).sendKeys(strText);
					getWebDriver().findElement(By.xpath(strXPATH)).sendKeys(Keys.TAB);
				}

			}
			catch(Exception e)
			{
				e.printStackTrace();
				throw e;
			}
		}
	}

	public void clickTab(String strXPATH, String strField) throws Exception
	{
		try{
			waitForObjectBeClickable(strXPATH, strField);
			int i=0;
			while(!getWebDriver().findElement(By.xpath(strXPATH)).getAttribute("class").equalsIgnoreCase("instncNtbkTabActive")){
				Thread.sleep(1000);
				getWebDriver().findElement(By.xpath(strXPATH)).click();
				waitForObjectBeClickable(strXPATH, strField);
				
				++i;
				if(i==25)
					break;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}
	
	public void clickTab1(String strXPATH, String strClass) throws Exception
	{
		try{
			waitForObjectBeClickable(strXPATH, strXPATH);
			int i=0;
			while(!getWebDriver().findElement(By.xpath(strXPATH)).getAttribute("class").equalsIgnoreCase(strClass)){
				Thread.sleep(1000);
				getWebDriver().findElement(By.xpath(strXPATH)).click();
				
				waitForObjectBeClickable(strXPATH, strXPATH);
				++i;
				if(i==25)
					break;
			}
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	}


	public void removeSuspence() throws Exception
    {
          //int a ;
          try{
                List<WebElement> rows = getWebDriver().findElements(By.xpath("//table[@id='SuspenseInfo']//tr"));
                String strSuspence = "" ;
                String strCode="";
                String strDesc= "" ;
                //              int flag=-1;
                for(int i=2;i<=rows.size();i++)
                {
                      //                    flag=0;
                      if(getWebDriver().findElements(By.xpath("//table[@id='SuspenseInfo']//tr["+i+"]//td[3]")).size()>0){
                            if(getWebDriver().findElement(By.xpath("//table[@id='SuspenseInfo']//tr["+i+"]//td[3]")).isDisplayed()){
                                  getWebDriver().findElement(By.xpath("//table[@id='SuspenseInfo']//tr["+i+"]//td[3]")).click();
                                  //                                flag=1;
                                  strCode = getWebDriver().findElement(By.xpath("//table[@id='SuspenseInfo']//tr["+i+"]//td[1]")).getText().trim();
                                  strDesc = getWebDriver().findElement(By.xpath("//table[@id='SuspenseInfo']//tr["+i+"]//td[2]")).getText().trim();
                                  //                                  ExcelHandling.setCellData(strCode, "SuspenceCode" + (i-1));
                                  //                                  ExcelHandling.setCellData(strDesc, "SuspenceDescription" + (i-1));
                                  strSuspence = strSuspence + strCode + ": " + strDesc + " ~";                              
                            }
                      }
                      if(getWebDriver().findElements(By.xpath("//table[@id='SuspenseInfo']//tr["+i+"]//td[3]//input")).size()>0){
                            if(getWebDriver().findElement(By.xpath("//table[@id='SuspenseInfo']//tr["+i+"]//td[3]//input")).isDisplayed()){
                                  getWebDriver().findElement(By.xpath("//table[@id='SuspenseInfo']//tr["+i+"]//td[3]//input")).clear();
                                  try{
                                        Thread.sleep(1000);
                                  }
                                  catch(Exception ex)
                                  {

                                  }
                                  getWebDriver().findElement(By.xpath("//table[@id='SuspenseInfo']//tr["+i+"]//td[3]//input")).sendKeys("Yes");
                                  getWebDriver().findElement(By.xpath("//table[@id='SuspenseInfo']//tr["+i+"]//td[3]//input")).sendKeys(Keys.TAB);
                                  try{
                                        Thread.sleep(1000);
                                  }
                                  catch(Exception ex)
                                  {

                                  }
                            }

                      }
                }
                String str1 = ExcelHandling.getCellData("Day");
                ExcelHandling.setCellData(strSuspence, "Day" + str1   + "_Suspense");
                Log.info("Suspences", "Suspense generated: ~" + strSuspence, "Done" ,takeScreenshot());
          }
          catch(Exception e)
          {
                e.printStackTrace();
                throw e;
          }
    }
	
	public boolean waitForObjectBeClickable1(String strXPATH, String strField) throws Exception {

		if (wait.until(ExpectedConditions.elementToBeClickable(By.xpath(strXPATH))) != null) {
//			Log.pass("waitForObjectBeClickable",  "object ." + strField + " is  clickable." ,"success");
			takeScreenshot();
			return true;
		} else {
			//Log.fail("waitForObjectBeClickable",  "object ." + strField + " is not clickable." ,"fail");
			takeScreenshot();
			return false;
		}
		
	} 
	
	public boolean validateObjectExist(String strXPATH, String strField) throws Exception {
		if(getWebDriver().findElements(By.xpath(strXPATH)).size()>0){
			if(getWebDriver().findElement(By.xpath(strXPATH)).isDisplayed())
			{
				scrollingToElementofAPage(getWebDriver().findElement(By.xpath(strXPATH)));
				return true;
			}
			else
				return false;
		}
		else
			return false;
	}

	public void javaScriptClick(Element ele, String strField) {
		try{
			WebElement element = (WebElement) ele.getNative();
			if (element.isEnabled() && element.isDisplayed()) {

				((JavascriptExecutor)getWebDriver()).executeScript(
						"arguments[0].click();", (WebElement)element);
				Log.info("javaScriptClick",  "Element " + strField + " clicked." ,"success");
			} else {
				Log.error("javaScriptClick",  "Element " + strField + " is disabled." ,"fail");
			}
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
			Log.error("javaScriptClick",  "Element " + strField + " is disabled." ,"fail");
		}
	}
	/*
	 * Method to get the current page URL
	 */
	public String getPageURL() {
		String actualURL;
		try {
			//Log.info("Method 'getPageURL' starts here");
			actualURL = getWebDriver().getCurrentUrl();
		} catch (Exception ex) {
			throw ex;
		}
		return actualURL;
	}

	/*
	 * Method to get the current page Title
	 */
	public String getPageTitle() {
		String actualTitle;
		try {
			//Log.info("Method 'getPageTitle' starts here");
			actualTitle = getWebDriver().getTitle();
		} catch (Exception ex) {
			throw ex;
		}
		return actualTitle;
	}

	/*
	 * Method to get the inner Text of the element
	 */
	public String getText(Element element) {
		WebElement ele = (WebElement) element.getNative();
		String text = ele.getText();
		return text;
	}

	/*
	 * Method to Check if the element(Radiobutton/Checkbox) is selected
	 */
	public boolean isSelected(Element element) {
		try {
			WebElement ele = (WebElement) element.getNative();
			return (ele.isSelected());
		} catch (Exception e) {
			return false;
		}
	}

	public  String takeScreenshot() throws Exception{
		try{
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy.MM.dd.HH.mm.ss");
			Timestamp timestamp = new Timestamp(System.currentTimeMillis());
			//format timestamp
			//		        System.out.println(sdf.format(timestamp).replace(".", "_"));

			File scrFile = ((TakesScreenshot)getWebDriver()).getScreenshotAs(OutputType.FILE);
			String strFile = ExcelHandling.strTestCaseName + sdf.format(timestamp).replace(".", "_") ;
			FileUtils.copyFile(scrFile, new File(Constant.Path_ScreenShot + strFile +".png"));	
			return Constant.Path_ScreenShot + strFile +".png" ;

		} catch (Exception e){
			Log.error("takeScreenshot" ,"Class Utils | Method takeScreenshot | Exception occured while capturing ScreenShot : "+e.getMessage() , "Fail");

			throw new Exception();

		}
	}
	/*
	 * Method to Check if data is present
	 */
	public boolean isDataPresent(String data) {
		try {
			if (data.isEmpty() || data.length() == 0 || data == null || data.equals("null")) {
				return false;
			} else {
				return true;
			}
		} catch (Exception e) {
			return false;
		}
	}

	/*
	 * Method to switch to child window
	 */
	public void switchWindow() {
		//;;Log.info("***** In method 'switchWindow()' ");

		WebDriver webDriver = getWebDriver();
		Set<String> handles = webDriver.getWindowHandles();
		System.out.println("No. of windows is: " + handles.size());

		for (String winHan : handles) {
			System.out.println(winHan);
			webDriver.switchTo().window(winHan);
		}
	}

	/*
	 * Java Method for Wait
	 */
	public void wait(int waitTime) {
		long endTime = System.currentTimeMillis() + (waitTime * 1000);
		while (System.currentTimeMillis() < endTime) {
		}
	}

	// Method written to write returning pageobject
	public WebDriver getDriver() {
		if (webDriver != null) {
			return webDriver;
		}
		return getWebDriver();
	}


	/*
	 * Method to switch to alert and accept it
	 */
	public void acceptAlert() {
		try {

			WebDriverWait wait = new WebDriverWait(getWebDriver(), 30);
			wait.until(ExpectedConditions.alertIsPresent());
			Alert alert = getWebDriver().switchTo().alert();
			alert.accept();

		} catch (Exception e) {
			e.getMessage();
		}

	}

	public void waitForObjectBeClickable(String strXPATH, String strField) {

		if (wait.until(ExpectedConditions.elementToBeClickable(By
				.xpath(strXPATH))) != null) {
			Log.info("waitForObjectBeClickable",  "object ." + strField + " is  clickable." ,"success");
		} else {
			Log.error("waitForObjectBeClickable",  "object ." + strField + " is not clickable." ,"fail");
		}
	}

	public void scrollingToElementofAPage(WebElement element) {
		try{
			//		WebElement element = getDriver().findElement(By.xpath(strXPATH));
			String id = element.getAttribute("id");
			if(!id.trim().equalsIgnoreCase("")){
				((JavascriptExecutor) getDriver()).executeScript(
						"document.getElementById('"+id+"').scrollIntoView();");
				//		Log.info("scrollingToElementofAPage",  "Scrolled to element " + strField + "."  ,"success");
			}
		}
		catch(Exception e)
		{
			System.out.println(e.toString());
		}

	}

	public boolean isAlertPresent() {
		System.out.println("Verifying if alert is present");
		try {
			getWebDriver().switchTo().alert();
			return true;
		}// try
		catch (NoAlertPresentException ex) {
			return false;
		}

		/*try {
			WebDriverWait wait = new WebDriverWait(getWebDriver(), 2);
			wait.until(ExpectedConditions.alertIsPresent());
			return true;
		} catch (Exception Ex) {
			return false;
		}*/
		/*try {
				getWebDriver().getTitle();
	            return false;
	        } catch (UnhandledAlertException e) {
	            // Modal diaLog showed
	            return true;
	        }*/
	}


	/**
	 * @Description : Wait for page load.
	 * @return boolean
	 */
	public boolean waitForPageLoad() {
		int waitTime = new Double(20).intValue();
		WebDriver driver = getDriver();
		ExpectedCondition<Boolean> pageLoad = new ExpectedCondition<Boolean>() {
			@Override
			public Boolean apply(WebDriver driver) {
				return ((JavascriptExecutor) driver).executeScript("return document.readyState").equals("complete");
			}
		};

		Wait<WebDriver> wait = new WebDriverWait(driver, waitTime);

		try {
			wait.until(pageLoad);
		} catch (Throwable pageLoadWaitError) {

			return false;

		}
		return true;
	}

	/**
	 * @Description : Window Switch Type.
	 * @return enum
	 */
	private enum WindowSwitchType {

		/** The by wintitle. */
		BY_WINTITLE,
		/** The by winurl. */
		BY_WINURL,
		/** The by frame. */
		BY_FRAME,
		/** The by parentframe. */
		BY_PARENTFRAME,
		/** The by default. */
		BY_DEFAULT,
		/** The by winclose. */
		BY_WINCLOSE,
		/** The by alert. */
		BY_ALERT,
		/** The by windowdiaLog */
		BY_WINDOWDIALog_TITLE,
		/** The by frame index */
		BY_FRAME_INDEX,
		/** The by winID. */
		BY_WINID;
	}

	/**
	 * @Description : Switch window.
	 * @param String : switchType ,winExpValue
	 * @return boolean
	 */
	private boolean switchWindow(String switchType, String winExpValue) {

		//Log.info("***** In method 'switchWindow()' for: " + switchType + " *****");

		WebDriver webDriver = getWebDriver();
		boolean bSwitchWindow = false;
		String winActValue = "";
		Set<String> availableWindows = webDriver.getWindowHandles();
		if (!availableWindows.isEmpty()) {
			for (String windowId : availableWindows) {
				if (switchType.equalsIgnoreCase("BY_WINTITLE")) {
					winActValue = webDriver.switchTo().window(windowId).getTitle().trim().toLowerCase();
				} else {
					winActValue = webDriver.switchTo().window(windowId).getCurrentUrl().trim().toLowerCase();
				}

				winExpValue = winExpValue.trim().toLowerCase();
				if (winActValue.contains(winExpValue)) {
					bSwitchWindow = true;
					//Log.info("Window '" + winExpValue + "' switched successfully!!");
					getWebDriver().manage().window().maximize();
					break;
				}
			}

			//Log.info("***** Exit method 'switchWindow()' for: " + switchType + " *****");
		}

		return bSwitchWindow;
	}
	/**
	 * @Description : Switch window diaLog.
	 * @param String :switchType ,winExpValue
	 * @return boolean
	 */
	public boolean switchWindowDiaLog(String switchType, String winExpValue) {

		try {

			//Log.info("***** In method 'switchWindowDiaLog()' for: " + switchType + " *****");
			waitForPageLoad();
			WebDriver webDriver = getWebDriver();
			String currentWindowId = webDriver.getWindowHandle();

			for (String winHandle : webDriver.getWindowHandles()) {
				String actualWindowTitle = webDriver.switchTo().window(winHandle).getTitle();
				if (actualWindowTitle.contains(winExpValue) && !currentWindowId.equals(winHandle)) {
					webDriver.switchTo().window(winHandle);
					break;
				}
			}
			// Thread.sleep(1000);
			waitForPageLoad();

		} catch (Exception ex) {

			return false;
		}

		return true;
	}

	/**
	 * @Description : Switch to.
	 * @param String:switchType , switchExpValue 
	 * @return  boolean
	 */
	public boolean switchTo(String switchType, String switchExpValue) {
		try {
			switch (WindowSwitchType.valueOf(switchType)) {
			case BY_WINTITLE:
				return switchWindow(switchType, switchExpValue);
			case BY_WINURL:
				return switchWindow(switchType, switchExpValue);
			case BY_WINDOWDIALog_TITLE:
				return switchWindowDiaLog(switchType, switchExpValue);
			case BY_FRAME:
				getWebDriver().switchTo().defaultContent();
				getWebDriver().switchTo().frame(switchExpValue);
				break;
			case BY_FRAME_INDEX:
				getWebDriver().switchTo().defaultContent();
				getWebDriver().switchTo().frame(Integer.parseInt(switchExpValue));
				break;
			case BY_PARENTFRAME:
				getWebDriver().switchTo().parentFrame();
				break;
			case BY_DEFAULT:
				getWebDriver().switchTo().defaultContent();
				break;
			case BY_WINCLOSE:
				getWebDriver().close();
				break;
			case BY_ALERT:
				WebDriverWait alertWait = new WebDriverWait(getWebDriver(), 5);
				alertWait.until(ExpectedConditions.alertIsPresent());
				Alert alert = getWebDriver().switchTo().alert();
				alert.accept();
				break;
			case BY_WINID:
				getWebDriver().switchTo().window(switchExpValue);
				break;
			default:
				throw new IllegalArgumentException("Parameter switchtype should be BY_WINTITLE| BY_WINURL|BY_FRAME|BY_PARENTFRAME|BY_DEFAULT|BY_ALERT");
			}

		} catch (Exception e) {
			e.printStackTrace();
			return false;
		}

		return true;
	}


	/**
	 * @Description : Checks if is element present.
	 * @param Element : elem
	 * @return boolean
	 */
	public boolean isElementPresent(Element elem) {
		try {

			elem.isPresent();

		} catch (Exception ex) {
			return false;
		}
		return true;
	}


	/**
	 * @Description :Gets the selected option.
	 * @param Element : elem
	 * @return String
	 */
	public String getSelectedOption(Element elem) {
		try {
			WebElement webElement = (WebElement) elem.getNative();
			Select sel = new Select(webElement);
			String text = sel.getFirstSelectedOption().getText();
			return text;

		} catch (Exception ex) {
			//Log.error(ex);
			return null;
		}

	}

	//	public void clkCreateNewQuote(Element elem1, Element elem2)
	//	{
	//		WebDriver driver = getWebDriver();
	//		WebElement webElement1 = (WebElement) elem1.getNative();
	//		WebElement webElement2 = (WebElement) elem2.getNative();
	//		do
	//		{
	//			
	//		}driver.findElement(By.xpath(xpathExpression))
	//	}
	
	public void selectOption(String Option) throws Exception
	{
		if(!Option.trim().equalsIgnoreCase("")){
			try{
				Thread.sleep(500);
				waitForObjectBeClickable("//*[text()='"+Option+"']" , Option);
				getWebDriver().findElement(By.xpath("//*[text()='"+Option+"']")).click();
			}
			catch(Exception e)
			{
				throw e;
			}
		}
	}
	
	public void scrapeCoveragePremiumNB(String strSheetName , int iVehicleNum) throws Exception
	{
		try{
			refreshDom();
			Thread.sleep(4000);
			String str1 = "Vehicle Number: " + iVehicleNum + "~";
			ExcelHandling.setExcelFile(Constant.Path_TestData + Constant.File_TestData,strSheetName);
			waitForObjectBeClickable("//table[@id='VehicleCoverage']//tr[1]//td[1]", strSheetName);
			scrollingToElementofAPage(getWebDriver().findElement(By.xpath("//table[@id='VehicleCoverage']//tr[1]//td[1]")));
			List<WebElement> rows = getWebDriver().findElements(By.xpath("//table[@id='VehicleCoverage']//tr"));
			int j=0 ;

			if(iVehicleNum==1)
				j=0;
			else if (iVehicleNum==2)
				j=20;
			else
				j=40;

			for(int i=2;i<=rows.size();i++)
			{
				waitForObjectBeClickable("//table[@id='VehicleCoverage']//tr["+i+"]//td[1]", strSheetName);
				String strCode = getWebDriver().findElement(By.xpath("//table[@id='VehicleCoverage']//tr["+i+"]//td[1]")).getText().trim();
				String strFTP = getWebDriver().findElement(By.xpath("//table[@id='VehicleCoverage']//tr["+i+"]//td[4]")).getText().trim();
				String strOP = getWebDriver().findElement(By.xpath("//table[@id='VehicleCoverage']//tr["+i+"]//td[6]")).getText().trim();
				//				ExcelHandling.setCellData("", strCode + "_FTP");
				ExcelHandling.setCellData(strCode + "_FTP"+ iVehicleNum + ": "+ strFTP,  "Record"+ (++j));

				str1 = str1 + strCode + " Full Term Premium " + ": "+ strFTP + "~" ;
				//				ExcelHandling.setCellData("", strCode + "_OP");
				//				ExcelHandling.setCellData(strOP, strCode + "_OP" + iVehicleNum);
				ExcelHandling.setCellData(strCode + "_OP"+ iVehicleNum + ": "+ strOP,  "Record"+ (++j));
				//				str1 = str1 + strCode + " Occasional Premium "+  ": "+ strOP +"~" ;
			}

			ExcelHandling.setExcelFile(Constant.Path_TestData + Constant.File_TestData,"VehicleAuto");
//			Log.info1( "Coverage Premium: ~" +  str1);
			Log.info("DriverMethods : scrapeCoveragePremium; Coverage Premium: ~" +  str1, "scrapeCoveragePremium Done", "Done");
			scrapeCoveragePremiumPhysicalDamageNB(strSheetName, iVehicleNum, j);
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	} 
	
	public void scrapeCoveragePremiumPhysicalDamageNB(String strSheetName , int iVehicleNum , int j) throws Exception
	{
		try{
			refreshDom();
			String str1 = "Vehicle Number: " + iVehicleNum + "~"; ;
			ExcelHandling.setExcelFile(Constant.Path_TestData + Constant.File_TestData,strSheetName);
			waitForObjectBeClickable("//table[@id='VehicleDisDed']//tr[1]//td[1]", strSheetName);
			scrollingToElementofAPage(getWebDriver().findElement(By.xpath("//table[@id='VehicleDisDed']//tr[1]//td[1]")));
			List<WebElement> rows = getWebDriver().findElements(By.xpath("//table[@id='VehicleDisDed']//tr"));

			for(int i=2;i<=rows.size();i++)
			{
				waitForObjectBeClickable("//table[@id='VehicleDisDed']//tr["+i+"]//td[1]", strSheetName);
				String strCode = getWebDriver().findElement(By.xpath("//table[@id='VehicleDisDed']//tr["+i+"]//td[1]")).getText().trim();
				String strFTP = getWebDriver().findElement(By.xpath("//table[@id='VehicleDisDed']//tr["+i+"]//td[7]")).getText().trim();
				//				String strOP = getWebDriver().findElement(By.xpath("//table[@id='VehicleDisDed']//tr["+i+"]//td[5]")).getText().trim();
				//				ExcelHandling.setCellData("", strCode + "_FTP");
				//				ExcelHandling.setCellData(strFTP, strCode + "_FTP"+ iVehicleNum);
				ExcelHandling.setCellData(strCode + "_FTP"+ iVehicleNum + ": "+ strFTP,  "Record"+ (++j));

				str1 =  str1 + strCode + " Full Term Premium " + ": "+ strFTP + "~" ;
				//				ExscelHandling.setCellData("", strCode + "_OP");
				//				ExcelHandling.setCellData(strOP, strCode + "_OP" + iVehicleNum);
				//				ExcelHandling.setCellData(strCode + "_OP"+ iVehicleNum + ": "+ strOP,  "Record"+ (++j));
			}
			ExcelHandling.setExcelFile(Constant.Path_TestData + Constant.File_TestData,"VehicleAuto");
			
			Log.info("DriverMethods : scrapeCoveragePremiumPhysicalDamage", "Physical Damage Coverages: ~" + str1, "Done" , takeScreenshot());
			Log.info("DriverMethods : scrapeCoveragePremiumPhysicalDamage", "scrapeCoveragePremiumPhysicalDamage Done", "Done");
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw e;
		}
	} 
	
	public void refreshDom()
	{
		try {
			//	Log.info("***** In method 'openURL()' for URL: " + url + " *****");
			getWebDriver().manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);


			//	Log.info("***** Exiting method 'openURL()' for URL: " + url + " *****");
		} catch (Exception ex) {
			throw ex;


		}
	} 

}
