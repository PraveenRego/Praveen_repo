  package com.allstate.ACGAutomation.Utility;


import org.apache.log4j.Logger;

import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

public class Log {
	// Initialize Log4j logs
	private static Logger Log = Logger.getLogger(Log.class.getName()); 
	// This is to print log for the beginning of the test case, as we usually run so many test cases as a test suite
	static String extentReportFile = System.getProperty("user.dir")
			+ "\\extentReportFile.html";
	static String extentReportImage = System.getProperty("user.dir")
			+ "\\extentReportImage.png";

	// Create object of extent report and specify the report file path.
	static ExtentReports extent = new ExtentReports(extentReportFile, false);
	static ExtentTest extentTest ;
	static String sTestCase = "" ;
	public static void startTestCase(String sTestCaseName){




		// Start the test using the ExtentTest class object.
		extentTest = extent.startTest(sTestCaseName);

		Log.info("****************************************************************************************");
		Log.info("****************************************************************************************");
		Log.info("$$$$$$$$$$$$$$$$$$$$$                 "+sTestCaseName+ "       $$$$$$$$$$$$$$$$$$$$$$$$$");
		Log.info("****************************************************************************************");
		Log.info("****************************************************************************************");
		sTestCase = sTestCaseName;
	}

	//This is to print log for the ending of the test case
	public static void endTestCase(String sTestCaseName){
		Log.info("XXXXXXXXXXXXXXXXXXXXXXX             "+"-E---N---D-"+"             XXXXXXXXXXXXXXXXXXXXXX");
		Log.info("X");
		Log.info("X");
		Log.info("X");
		Log.info("X");

		// close report.
		extent.endTest(extentTest);
		// writing everything to document.
		extent.flush();
	}

	// Need to create these methods, so that they can be called  
	public static void info(String methodname , String description, String sStatus) {
		Log.info(methodname + "|" + description + "|"+   sStatus);
		extentTest.log(LogStatus.INFO, methodname + "|" + description + "|"+   sStatus);

	}

	public static void info(String methodname , String description, String sStatus , String strFilename) {

		extentTest.log(
				LogStatus.INFO,
				" Snapshot : "
						+ extentTest.addScreenCapture(strFilename.replace("//", "/")));
	}

	public static void pass(String methodname , String description) {
		String sStatus = "Pass";
		Log.info(methodname + "|" + description + "|"+   sStatus);
		extentTest.log(LogStatus.PASS, methodname + "|" + description + "|"+   sStatus);

	}
	
	public static void pass(String methodname , String description , String strFilename) {
		String sStatus = "Pass";
		Log.info(methodname + "|" + description + "|"+   sStatus);
		extentTest.log(LogStatus.PASS, methodname + "|" + description + "|"+   sStatus);
		extentTest.log(
				LogStatus.PASS,
				" Snapshot : "
						+ extentTest.addScreenCapture(strFilename.replace("//", "/")));

	}
	
	public static void warn(String message) {
		Log.warn(message);
	}
	public static void error(String methodname , String description, String sStatus) {
		//		sStatus = "Fail" ;
		Log.error(methodname + "|" + description + "|"+   sStatus);
		extentTest.log(LogStatus.ERROR, methodname + "|" + description + "|"+   sStatus);
		
		

	}
	
	public static void fail(String methodname , String description, String sStatus) {
		//		sStatus = "Fail" ;
		Log.error(methodname + "|" + description + "|"+   sStatus);
		extentTest.log(LogStatus.FAIL, methodname + "|" + description + "|"+   sStatus);
		
		

	}
	
	
	
	public static void error(String methodname , String description, String sStatus, String strFilename) {
		//		sStatus = "Fail" ;
		Log.error(methodname + "|" + description + "|"+   sStatus);
		extentTest.log(LogStatus.FAIL, methodname + "|" + description + "|"+   sStatus);
		
		extentTest.log(
				LogStatus.FAIL,
				" Snapshot : "
						+ extentTest.addScreenCapture(strFilename.replace("//", "/")));

	}
	
	public static void fail(String methodname , String description, String sStatus, String strFilename) {
		//		sStatus = "Fail" ;
		Log.error(methodname + "|" + description + "|"+   sStatus);
		extentTest.log(LogStatus.FAIL, methodname + "|" + description + "|"+   sStatus);
		
		extentTest.log(
				LogStatus.FAIL,
				" Snapshot : "
						+ extentTest.addScreenCapture(strFilename.replace("//", "/")));

	}
	
	public static void fatal(String message) {
		Log.fatal(message);
	}
	public static void debug(String message) {
		Log.debug(message);
	}
}
