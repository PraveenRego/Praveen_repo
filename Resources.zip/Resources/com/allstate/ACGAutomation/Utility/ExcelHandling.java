 package com.allstate.ACGAutomation.Utility;


import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;

import org.apache.poi.ss.usermodel.CellValue;
import org.apache.poi.ss.usermodel.FormulaEvaluator;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class ExcelHandling {

	private static XSSFSheet ExcelWSheet;
	private static XSSFWorkbook ExcelWBook;
	private static XSSFCell Cell;
	private static XSSFRow Row;
	public static String strTestCaseName = "" ;


	public  static String userid = "foCusAT_Rpt";
	public  static String password = "acgPswrd1!";
	public static String DBURL = "jdbc:sqlserver://dsql2008:1433;databaseName=foCusAutoTest";
	public static Connection conn = null;
	public static Statement stmt  = null ;
	public static String tableName = "" ;
	public static void setTestCaseName(String sTestCaseName)
	{
		strTestCaseName = sTestCaseName ;
	}


	//This method is to set the File path and to open the Excel file, Pass Excel Path and Sheetname as Arguments to this method
	public static void setExcelFile(String Path,String SheetName)  {
		try {
			if(Constant.Src_TestData.trim().equalsIgnoreCase("Excel")){

				// Open the Excel file
				// Path = "C://Users//ssah8//Downloads//OnlineStore//src//testData//testData.xlsx";
				FileInputStream ExcelFile = new FileInputStream(Path);
				// Access the required test data sheet
				ExcelWBook = new XSSFWorkbook(ExcelFile);
				ExcelWSheet = ExcelWBook.getSheet(SheetName);
			//	tableName = SheetName ;
			}
			else
			{
				Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
				conn = DriverManager.getConnection(DBURL,userid, password);
				stmt = conn.createStatement();
				System.out.println("connected");
				tableName = SheetName ;
			}
			//        Log.info("setExcelFile" ,"Excel sheet opened" , "Done");
		} catch (Exception e){
			System.out.println(e.toString());

		}
	}
	//This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num
	public static String getCellData(String sHeaderName) {
		try{
//			int a ;
			String str = "" ;
			if(Constant.Src_TestData.trim().equalsIgnoreCase("Excel")){
			int RowNum = getRowContains(strTestCaseName);
			int ColNum = getColContains(sHeaderName);
			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
			
			FormulaEvaluator evaluator = ExcelWBook.getCreationHelper().createFormulaEvaluator();
			CellValue cellValue = evaluator.evaluate(Cell);
			
			switch (cellValue.getCellType()) {
		    case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_STRING:
		        System.out.print(cellValue.getStringValue());
		        str = cellValue.getStringValue() ;
		        break;
//		    case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_BOOLEAN:
//		        System.out.print(cellValue.getBooleanValue());
//		       
//		        break;
		    case org.apache.poi.ss.usermodel.Cell.CELL_TYPE_NUMERIC:
		        System.out.print(cellValue.getNumberValue());
		        str = String.valueOf((int)cellValue.getNumberValue());
		        System.out.print(str);
		        break;
		}
		 
			
//			String CellData = Cell.getStringCellValue();
			
			
//			return CellData.trim();
			return str ;
			}
			else
			{
				ResultSet rs = stmt.executeQuery("Select "+sHeaderName+" from "+tableName+" where TestCaseName = '"+strTestCaseName+"'");
				rs.next();
				System.out.println(rs.getString(1));
				return rs.getString(1).trim();
				
			}
		}catch (Exception e){
			System.out.println(e.toString());
			return"";
		}
	}

	//This method is to read the test data from the Excel cell, in this we are passing parameters as Row num and Col num
	public static String getCellData(int  RowNum, int ColNum) throws Exception{
		try{

			Cell = ExcelWSheet.getRow(RowNum).getCell(ColNum);
			String CellData = Cell.getStringCellValue();
			return CellData.trim();
		}catch (Exception e){
			return"";
		}
	}

	//This method is to write in the Excel cell, Row num and Col num are the parameters
	@SuppressWarnings("static-access")
	public static void setCellData(String Result,  String sHeaderName)     {
		try{
			int a ;
			if(Constant.Src_TestData.trim().equalsIgnoreCase("Excel")){
				int RowNum = getRowContains(strTestCaseName);
				int ColNum = getColContains(sHeaderName);
				Row  = ExcelWSheet.getRow(RowNum);
				Cell = Row.getCell(ColNum, Row.RETURN_BLANK_AS_NULL);
				if (Cell == null) {
					Cell = Row.createCell(ColNum);
					Cell.setCellValue(Result.trim());
				} else {
					Cell.setCellValue(Result.trim());
				}
				// Constant variables Test Data path and Test Data file name
				FileOutputStream fileOut = new FileOutputStream(Constant.Path_TestData + Constant.File_TestData);
				ExcelWBook.write(fileOut);
				fileOut.flush();
				fileOut.close();
			}
			else
			{
				stmt.executeUpdate("update "+tableName+" set "+sHeaderName+"='"+Result+"'where TestCaseName = '"+strTestCaseName+"'");
			}
		}catch(Exception e){
			//                throw (e);
		}
	}

	public static int getRowContains(String sTestCaseName) throws Exception{
		int i;
		try {
			int rowCount = ExcelHandling.getRowUsed();
			for ( i=0 ; i<rowCount; i++){
				if  (ExcelHandling.getCellData(i,0).equalsIgnoreCase(sTestCaseName)){
					break;
				}
			}
			return i;
		}catch (Exception e){
			Log.error("setExcelFile" , "Class ExcelUtil | Method getRowContains | Exception desc : " + e.toString(), "Done");
			throw(e);
		}
	}

	public static int getColContains(String sHeaderName) throws Exception{
		int a ;
		int j;
		try {
			int colCount= ExcelWSheet.getRow(1).getLastCellNum();
			colCount = 999;

			for (  j=0 ; j<colCount; j++){
				if  (ExcelHandling.getCellData(0,j).equalsIgnoreCase(sHeaderName)){
					break;
				}
			}
			return j;
		}catch (Exception e){
			System.out.println(e.toString());
			Log.error("getColContains" , "Class ExcelUtil | Method getColContains | Exception desc : " + e.toString() , "Done");
			throw(e);
		}
	}

	public static int getRowUsed() throws Exception {
		try{
			int RowCount = ExcelWSheet.getLastRowNum();
			//		Log.info("getRowUsed" , "Total number of Row used return as < " + RowCount + " >." , "Done");		
			return RowCount;
		}catch (Exception e){
			Log.error("getRowUsed" , "Class ExcelUtil | Method getRowUsed | Exception desc : "+e.toString() , "Done");
			System.out.println(e.getMessage());
			throw (e);
		}

	}
}