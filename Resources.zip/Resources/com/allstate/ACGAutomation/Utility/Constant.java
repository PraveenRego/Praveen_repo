package com.allstate.ACGAutomation.Utility;



public class Constant {
	    public static final String URL = "http://qa4focus.allstate.ca/#_";
	    public static final String Username = "agcsales";
	    public static final String Password ="agc$1234";
//		public static final String Path_TestData = "D://NewFramework//FocusAutomation_NMPPAuto//FocusAutomationPOCAuto//Resources//Test Data//";
		public static final String Path_TestData = System.getProperty("user.dir")+ "//Resources//Test Data//";
		public static final String File_TestData = "TestData.xlsx";
		public static final String Src_TestData = "Excel"; // Excel/Db
		
		//Test Data Sheet Columns
		public static final int Col_TestCaseName = 0;	
		public static final int Col_UserName =1 ;
		public static final int Col_Password = 2;
		public static final int Col_Browser = 3;
		public static final int Col_ProductType = 4;
		public static final int Col_ProductNumber = 5;
		public static final int Col_FirstName = 6;
		public static final int Col_LastName = 7;
		public static final int Col_Address = 8;
		public static final int Col_City = 9;
		public static final int Col_Country = 10;
		public static final int Col_Phone = 11;
		public static final int Col_Email = 12;
		public static final int Col_Result = 13;
//		public static final String Path_ScreenShot = "S://prog-shared area//Sounak//Screenshots//";
		public static final String Path_ScreenShot = "D://NewFramework//FocusAutomation_NMPPAuto//FocusAutomationPOCAuto//Resources//Screenshots//";
		public static final String PDF_FILE_NAME = System.getProperty("user.dir")+ "//Resources//Docs//AUTODK_1_BLUE_1b4.83.pdf";
	}



