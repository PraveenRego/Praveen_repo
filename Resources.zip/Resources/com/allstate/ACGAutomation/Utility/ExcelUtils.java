package com.allstate.ACGAutomation.Utility;


import org.xframium.page.LocalAbstractPage;
import org.xframium.page.data.PageData;
import org.xframium.page.data.PageDataManager;



public class ExcelUtils {
	
	PageDataManager dataManager = null;
	LocalAbstractPage lbs = null;
	
	DriverMethods driverMethods = null;
	
	String dataSetID = null;


	public void initializePage() {
		driverMethods = new DriverMethods();
		dataManager = PageDataManager.instance();
	}

	public ExcelUtils(LocalAbstractPage lbs, PageDataManager dataManager) {
		this.lbs = lbs;
		this.dataManager = dataManager;
		//abstractPage = lbs;
		// driverMethods = new DriverMethods();
	}
	/**
     * @Description : This method is used when there is a need to get some respective data from the PageData file.
     * @param String : locator
     * @return String
     * 
     */
    public String getData(String columnName) {

        try {
        	int a ;
                        
            String recordSheet = lbs.getClass().getSimpleName().replace("Impl", "").trim();
            
            recordSheet = "DesktopPage" ;
                        
                PageData pageData = dataManager.getPageData(recordSheet);

                return pageData.getData(columnName).trim();
           
            
        } catch (Exception ex) {

            throw ex;
        }

    }
}
