package com.allstate.ACGAutomation.Utility;

import com.itextpdf.text.pdf.PdfReader;
import com.itextpdf.text.pdf.parser.PdfTextExtractor;

import java.io.IOException; 


public class PdfValidation {

	static PdfReader reader;
	//private static final String FILE_NAME = "C:/Users/ssaha0ca/Downloads/AUTODK_1_BLUE_c96.ac.pdf";
	static String textFromPage = "";

	public static int searchPolicyNumber(String polNum, String PageType)
	{
		try {
			polNum = convertPolNum(polNum);
			reader = new PdfReader(Constant.PDF_FILE_NAME);
			int pageNumber = 0 ;

			boolean found = false ;
			for(int i=1 ; i <=reader.getNumberOfPages() ;i++ )
			{
				textFromPage = PdfTextExtractor.getTextFromPage(reader, i);
				if(PageType.equalsIgnoreCase("Front Page")){
					if((textFromPage.contains("YOUR ALLSTATE POLICY AT A GLANCE") && textFromPage.contains(polNum)))
					{
						found= true ;
						pageNumber = i;
						break;
					}
				}
				else
				{
					if(textFromPage.contains("BILLING NOTICE") & textFromPage.contains(polNum))
					{
						found= true ;
						pageNumber = i;
						break;
					}
				}
			}
			if(found)
			{
				System.out.println("Found at Page No. " + pageNumber);
				
				reader.close();
				return pageNumber ; 
			}
			else
			{
				System.out.println("Not Found " + polNum);
				reader.close();
				Log.fail("searchPolicyNumber", "Not Found " + polNum, "Fail");
				return -1;
			}



		} catch (IOException e) {
			// TODO Auto-generated catch blockformNumber
			e.printStackTrace();
			reader.close();
			return -1;
		}
	}
	
	public static void validateLiabilityCardG10001(String polNum)
	{
		try {
			polNum = convertPolNum(polNum);
			reader = new PdfReader(Constant.PDF_FILE_NAME);
			int pageNumber = 0 ;

			boolean found = false ;
			for(int i=1 ; i <=reader.getNumberOfPages() ;i++ )
			{
				textFromPage = PdfTextExtractor.getTextFromPage(reader, i);
				
					if((textFromPage.contains("Enclosed is your new Canada Inter-Province Liability card(s)") && textFromPage.contains(polNum)))
					{
						found= true ;
						pageNumber = i;
						break;
					}
			}
			if(found)
			{
				System.out.println("Liability card G10001 found at Page No. " + pageNumber + " for policy number "+ polNum);
				Log.pass("validateLiabilityCardG10001", "Liability card G10001 found at Page No. " + pageNumber);
				reader.close();
			}
			else
			{
				System.out.println("Liability card G10001 not Found " + pageNumber);
				Log.fail("validateLiabilityCardG10001", "Liability card G10001 not Found " + pageNumber+ " for policy number "+ polNum, "Fail");
				reader.close();
			}



		} catch (IOException e) {
			// TODO Auto-generated catch blockformNumber
			e.printStackTrace();
			reader.close();
		}
	}

	public static int searchPolicyNumber1(String polNum)
	{
		try {
			polNum = convertPolNum(polNum);
			reader = new PdfReader(Constant.PDF_FILE_NAME);
			int pageNumber = 0 ;

			boolean found = false ;
			for(int i=1 ; i <=reader.getNumberOfPages() ;i++ )
			{
				textFromPage = PdfTextExtractor.getTextFromPage(reader, i);

				if((textFromPage.contains("Insured�s  name and address") && textFromPage.contains(polNum)))
				{
					found= true ;
					pageNumber = i;
					break;
				}

			}
			if(found)
			{
				System.out.println("Found at Page No. " + pageNumber);
				reader.close();
				return pageNumber ; 
			}
			else
			{
				System.out.println("Not Found " + polNum);
				Log.fail("searchPolicyNumber", "Not Found " + polNum, "Fail");
				reader.close();
				return -1;
			}



		} catch (IOException e) {
			// TODO Auto-generated catch blockformNumber
			e.printStackTrace();
			reader.close();
			return -1;
		}
	}

	public static int searchPolicyNumberFrontPage(String polNum)
	{
		return searchPolicyNumber(polNum , "Front Page");
	}

	public static int searchPolicyNumberBillingPage(String polNum)
	{
		return searchPolicyNumber(polNum , "Billing Page");
	}
	
	public static void validateformNumber(String polNum , int pageNum, String FormNumber)
	{
		int a ;
		try {
			int j=0;
			int i=0;
			switch(FormNumber)
			{
			case "A12406": case "A12404": case "A20004": case "A20101": case "A20201": case "LIABILITY INSURANCE CARD": case "A12603": case "A12903": case "A20301": case "A12903_1": case "A12602":
				i=searchPolicyNumberFrontPage(polNum);
				break;

			case "A10300": case "A10400":
				i=searchPolicyNumber1(polNum);

				break;

			default: Log.fail("ValidatePdf: Execute", "Invalid Form Number:" + FormNumber +". Kindly check.", "Error");
			}

			reader = new PdfReader(Constant.PDF_FILE_NAME);
			switch(pageNum)
			{
			case 1:
				textFromPage = PdfTextExtractor.getTextFromPage(reader, i);
				j=i;break;
			case 2:
				textFromPage = PdfTextExtractor.getTextFromPage(reader, i+1);
				j=i+1;break;
			case 3:
				textFromPage = PdfTextExtractor.getTextFromPage(reader, i+6);
				j=i+6;break;
			case 4:
				textFromPage = PdfTextExtractor.getTextFromPage(reader, i+7);
				j=i+7;break;
			default:
				Log.fail("ValidatePdf: Execute", "Invalid input for pageNum:" + pageNum +". Kindly check.", "Error");
				
			}
//			if(pageNum==1){
//				textFromPage = PdfTextExtractor.getTextFromPage(reader, i);
//				j=i;
//			}
//			else if(pageNum==2)
//			{
//				textFromPage = PdfTextExtractor.getTextFromPage(reader, i+1);
//				j=i+1;
//			}
			FormNumber= FormNumber.replace("_1", "");
			if(textFromPage.contains(FormNumber))
			{
				System.out.println("Form Number: " + FormNumber +" generated for policy " + polNum + "at page no. " + j);
				Log.pass("validateformNumber", "Form Number: " + FormNumber +" generated for policy " + polNum + "at page no. " + j);
			}
			else
			{
				System.out.println("Form Number: " + FormNumber +" not generated for policy " + polNum);
				Log.fail("validateformNumber", "Form Number: " + FormNumber +" not generated for policy " + polNum, "Fail");
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch blockformNumber
			e.printStackTrace();
		}

	}


	public static void validateInsuredDetails(String polNum)
	{
		try {
			int i = searchPolicyNumberFrontPage(polNum);
			reader = new PdfReader(Constant.PDF_FILE_NAME);
			textFromPage = PdfTextExtractor.getTextFromPage(reader, i);
			String insDetails = ""; 
			insDetails= textFromPage.substring(textFromPage.indexOf("Tel:")+"Tel:".length(),textFromPage.indexOf("Liability Cards")).trim();
			//			System.out.println(insDetails);
//			ExcelHandling.setCellData(insDetails, "InsuredDetails");	
			String strExp = ExcelHandling.getCellData("InsuredDetails").trim();
			if(strExp.trim().equalsIgnoreCase(insDetails)){
				Log.pass("validateInsuredDetails", "Insured Details validated successfully");
			}
			else
			{
				Log.fail("validateInsuredDetails", "Expected: " + strExp + " Actual value: " + insDetails, "Fail");
			}

			reader.close();

		} catch (IOException e) {
			// TODO Auto-generated catch blockformNumber
			e.printStackTrace();
		}

	}

	public static void validatePaymentDetails(String polNum)
	{
		try {
			int i = searchPolicyNumberBillingPage(polNum);
			reader = new PdfReader(Constant.PDF_FILE_NAME);
			textFromPage = PdfTextExtractor.getTextFromPage(reader, i);
			String pmtDetails = textFromPage.substring(textFromPage.indexOf("Method of Payment")+"Method of Payment".length(),textFromPage.indexOf("Payment Amounts")).trim();
			//			System.out.println(pmtDetails);
//			ExcelHandling.setCellData(pmtDetails, "PaymentDetails");
			String strExp = ExcelHandling.getCellData("PaymentDetails").trim();
			if(strExp.trim().equalsIgnoreCase(pmtDetails)){
				Log.pass("validatePaymentDetails", "Payment Details validated successfully");
			}
			else
			{
				Log.fail("validatePaymentDetails", "Expected: " + strExp + "\nActual value: " + pmtDetails, "Fail");
			}
			reader.close();
		} catch (IOException e) {
			// TODO Auto-generated catch blockformNumber
			e.printStackTrace();
		}

	}

	public static String convertPolNum(String strPolnum)
	{
		String str1 = "";
		str1 = strPolnum.trim().charAt(0) + " " + strPolnum.trim().charAt(1) + strPolnum.trim().charAt(2) + " " ;
		for (int i=3;i <=strPolnum.length()-1 ; i++ )
		{
			str1 = str1 + strPolnum.trim().charAt(i);
		}
		//		System.out.println(str1);
		return str1;
	}
	/*	
	public static void main(String[] args) {
//		validateformNumber("051000014", 2, "A20201");
//		validateInsuredDetails("051000014");
		validatePaymentDetails("051000014");

	}

	 */

}
